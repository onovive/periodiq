export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          username: string
          avatar_url: string | null
          avatar: string | null
          display_name: string | null
          explorer_type: string | null
          onboarding_completed: boolean
          role: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          username: string
          avatar_url?: string | null
          avatar?: string | null
          display_name?: string | null
          explorer_type?: string | null
          onboarding_completed?: boolean
          role?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          username?: string
          avatar_url?: string | null
          avatar?: string | null
          display_name?: string | null
          explorer_type?: string | null
          onboarding_completed?: boolean
          role?: string
          created_at?: string
          updated_at?: string
        }
      }
      hunts: {
        Row: {
          id: string
          title: string
          description: string
          difficulty: 'easy' | 'medium' | 'hard'
          duration_minutes: number
          max_participants: number | null
          start_time: string
          end_time: string
          status: 'upcoming' | 'active' | 'completed'
          created_by: string
          created_at: string
          game_image_url: string | null
          prizes: string[] | null
        }
        Insert: {
          id?: string
          title: string
          description: string
          difficulty: 'easy' | 'medium' | 'hard'
          duration_minutes: number
          max_participants?: number | null
          start_time: string
          end_time: string
          status?: 'upcoming' | 'active' | 'completed'
          created_by: string
          created_at?: string
          game_image_url?: string | null
          prizes?: string[] | null
        }
        Update: {
          id?: string
          title?: string
          description?: string
          difficulty?: 'easy' | 'medium' | 'hard'
          duration_minutes?: number
          max_participants?: number | null
          start_time?: string
          end_time?: string
          status?: 'upcoming' | 'active' | 'completed'
          created_by?: string
          created_at?: string
          game_image_url?: string | null
          prizes?: string[] | null
        }
      }
      clues: {
        Row: {
          id: string
          hunt_id: string
          order_number: number
          question: string
          hint: string | null
          expected_answer: string
          answer_type: 'text' | 'image' | 'both'
          validation_type: 'exact' | 'ai' | 'keyword'
          points: number
          created_at: string
        }
        Insert: {
          id?: string
          hunt_id: string
          order_number: number
          question: string
          hint?: string | null
          expected_answer: string
          answer_type?: 'text' | 'image' | 'both'
          validation_type?: 'exact' | 'ai' | 'keyword'
          points: number
          created_at?: string
        }
        Update: {
          id?: string
          hunt_id?: string
          order_number?: number
          question?: string
          hint?: string | null
          expected_answer?: string
          answer_type?: 'text' | 'image' | 'both'
          validation_type?: 'exact' | 'ai' | 'keyword'
          points?: number
          created_at?: string
        }
      }
      hunt_participants: {
        Row: {
          id: string
          hunt_id: string
          user_id: string
          status: 'registered' | 'subscribed' | 'active' | 'completed' | 'abandoned'
          started_at: string | null
          completed_at: string | null
          total_score: number
          created_at: string
        }
        Insert: {
          id?: string
          hunt_id: string
          user_id: string
          status?: 'registered' | 'subscribed' | 'active' | 'completed' | 'abandoned'
          started_at?: string | null
          completed_at?: string | null
          total_score?: number
          created_at?: string
        }
        Update: {
          id?: string
          hunt_id?: string
          user_id?: string
          status?: 'registered' | 'subscribed' | 'active' | 'completed' | 'abandoned'
          started_at?: string | null
          completed_at?: string | null
          total_score?: number
          created_at?: string
        }
      }
      submissions: {
        Row: {
          id: string
          hunt_participant_id: string
          clue_id: string
          answer: string
          image_url: string | null
          is_correct: boolean
          ai_feedback: string | null
          points_earned: number
          submitted_at: string
        }
        Insert: {
          id?: string
          hunt_participant_id: string
          clue_id: string
          answer: string
          image_url?: string | null
          is_correct: boolean
          ai_feedback?: string | null
          points_earned: number
          submitted_at?: string
        }
        Update: {
          id?: string
          hunt_participant_id?: string
          clue_id?: string
          answer?: string
          image_url?: string | null
          is_correct?: boolean
          ai_feedback?: string | null
          points_earned?: number
          submitted_at?: string
        }
      }
      rankings: {
        Row: {
          id: string
          hunt_id: string
          user_id: string
          rank: number
          total_score: number
          completion_time: string
          calculated_at: string
        }
        Insert: {
          id?: string
          hunt_id: string
          user_id: string
          rank: number
          total_score: number
          completion_time: string
          calculated_at?: string
        }
        Update: {
          id?: string
          hunt_id?: string
          user_id?: string
          rank?: number
          total_score?: number
          completion_time?: string
          calculated_at?: string
        }
      }
    }
  }
}
