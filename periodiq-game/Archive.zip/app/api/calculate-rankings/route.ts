import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'

export async function POST(request: Request) {
  try {
    const { huntId } = await request.json()

    if (!huntId) {
      return NextResponse.json({ error: 'Hunt ID is required' }, { status: 400 })
    }

    const supabase = await createClient()

    // Verify hunt exists and has ended
    const { data: hunt, error: huntError } = await supabase
      .from('hunts')
      .select('*')
      .eq('id', huntId)
      .single<any>()

    if (huntError || !hunt) {
      return NextResponse.json({ error: 'Hunt not found' }, { status: 404 })
    }

    const now = new Date()
    const endTime = new Date(hunt.end_time)

    if (now < endTime) {
      return NextResponse.json({ error: 'Hunt has not ended yet' }, { status: 400 })
    }

    // Check if rankings already exist
    const { data: existingRankings } = await supabase
      .from('rankings')
      .select('id')
      .eq('hunt_id', huntId)
      .limit(1)

    if (existingRankings && existingRankings.length > 0) {
      return NextResponse.json({ message: 'Rankings already calculated', alreadyExists: true })
    }

    // Calculate rankings using the database function
    // @ts-expect-error - RPC function type not properly inferred
    const { error: calcError } = await supabase.rpc('calculate_hunt_rankings', {
      hunt_id_param: huntId
    })

    if (calcError) {
      console.error('Error calculating rankings:', calcError)
      return NextResponse.json({ error: 'Failed to calculate rankings' }, { status: 500 })
    }

    return NextResponse.json({ message: 'Rankings calculated successfully', success: true })
  } catch (error: any) {
    console.error('Error in calculate-rankings API:', error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
