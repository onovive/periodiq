import { NextResponse } from 'next/server'

const GEMINI_API_KEY = process.env.GEMINI_API_KEY
const SIGHTENGINE_API_USER = process.env.SIGHTENGINE_API_USER
const SIGHTENGINE_API_SECRET = process.env.SIGHTENGINE_API_SECRET
const GOOGLE_VISION_API_KEY = process.env.GOOGLE_VISION_API_KEY

export async function POST(request: Request) {
  try {
    const { imageUrl, expectedAnswer, imageBase64 } = await request.json()

    console.log('=== Image Validation Started ===')
    console.log('Image URL:', imageUrl ? 'Provided' : 'Not provided')
    console.log('Image Base64:', imageBase64 ? 'Provided' : 'Not provided')
    console.log('Expected Answer:', expectedAnswer)

    if (!imageUrl && !imageBase64) {
      return NextResponse.json({ error: 'Image URL or base64 required' }, { status: 400 })
    }

    // Use imageUrl for AI check (SightEngine only accepts URLs)
    // Use imageBase64 for other checks if available, otherwise imageUrl
    const imageDataForChecks = imageBase64 || imageUrl

    console.log('\n--- Starting parallel checks ---')
    const [aiGenerated, foundOnWeb, matchesAnswer] = await Promise.all([
      checkAIGenerated(imageUrl, imageBase64),
      checkWebMatch(imageDataForChecks),
      checkAnswerMatch(imageDataForChecks, expectedAnswer)
    ])

    console.log('\n=== Validation Results ===')
    console.log('AI Generated:', aiGenerated)
    console.log('Found on Web:', foundOnWeb)
    console.log('Matches Answer:', matchesAnswer)
    console.log('Overall Valid:', !aiGenerated && !foundOnWeb && matchesAnswer)

    return NextResponse.json({
      valid: !aiGenerated && !foundOnWeb && matchesAnswer,
      aiGenerated,
      foundOnWeb,
      matchesAnswer,
      feedback: getFeedback(aiGenerated, foundOnWeb, matchesAnswer, expectedAnswer)
    })
  } catch (error: any) {
    console.error('Error in validation:', error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

async function checkAIGenerated(imageUrl: string | undefined, imageBase64: string | undefined): Promise<boolean> {
  console.log('\n[AI Check] Starting AI generation detection...')

  // SightEngine only works with URLs, skip if only base64 is provided
  if (!imageUrl) {
    console.log('[AI Check] Skipping - No URL provided (only base64)')
    return false
  }

  const url = `https://api.sightengine.com/1.0/check.json?api_user=${encodeURIComponent(SIGHTENGINE_API_USER || '')}&api_secret=${encodeURIComponent(SIGHTENGINE_API_SECRET || '')}`

  const payload = new URLSearchParams({
    url: imageUrl,
    models: 'genai'
  })

  try {
    console.log('[AI Check] Calling SightEngine API...')
    const response = await fetch(url, {
      method: 'POST',
      body: payload
    })
    const result = await response.json()
    console.log('[AI Check] SightEngine response:', JSON.stringify(result, null, 2))

    if (result.status === 'failure') {
      console.log('[AI Check] API Error:', result.error?.message)
      return false
    }

    const aiScore = result.type?.ai_generated || 0
    const isAI = aiScore > 0.7
    console.log('[AI Check] AI Score:', aiScore, '| Result:', isAI ? 'AI DETECTED' : 'PASS')

    return isAI
  } catch (e) {
    console.log('[AI Check] Error:', e)
    return false
  }
}

async function checkWebMatch(imageData: string): Promise<boolean> {
  console.log('\n[Web Check] Starting web match detection...')

  const url = `https://vision.googleapis.com/v1/images:annotate?key=${GOOGLE_VISION_API_KEY}`

  try {
    let base64Image = imageData
    if (imageData.startsWith('http')) {
      console.log('[Web Check] Converting URL to base64...')
      const imageResponse = await fetch(imageData)
      const buffer = await imageResponse.arrayBuffer()
      base64Image = Buffer.from(buffer).toString('base64')
    } else if (imageData.startsWith('data:')) {
      console.log('[Web Check] Extracting base64 from data URL...')
      base64Image = imageData.split(',')[1]
    }

    const payload = {
      requests: [{
        image: { content: base64Image },
        features: [{ type: 'WEB_DETECTION' }]
      }]
    }

    console.log('[Web Check] Calling Google Vision API...')
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })

    const result = await response.json()
    const webDetection = result.responses?.[0]?.webDetection
    console.log('[Web Check] Google Vision response:', JSON.stringify(webDetection, null, 2))

    const matchCount = webDetection?.fullMatchingImages?.length || 0
    const foundOnWeb = matchCount > 0

    console.log('[Web Check] Full matches found:', matchCount, '| Result:', foundOnWeb ? 'FOUND ON WEB' : 'PASS')

    return foundOnWeb
  } catch (e) {
    console.log('[Web Check] Error:', e)
    return false
  }
}

async function checkAnswerMatch(imageData: string, answer: string): Promise<boolean> {
  console.log('\n[Content Match] Starting content matching...')
  console.log('[Content Match] Expected answer:', answer)

  if (!GEMINI_API_KEY || !answer) {
    console.log('[Content Match] Skipping - Missing API key or answer')
    return false
  }

  try {
    let base64Image = imageData
    let mimeType = 'image/png'

    if (imageData.startsWith('http')) {
      console.log('[Content Match] Converting URL to base64...')
      const imageResponse = await fetch(imageData)
      const buffer = await imageResponse.arrayBuffer()
      base64Image = Buffer.from(buffer).toString('base64')
      mimeType = imageResponse.headers.get('content-type') || 'image/png'
    } else if (imageData.startsWith('data:')) {
      console.log('[Content Match] Extracting base64 from data URL...')
      const parts = imageData.split(',')
      mimeType = parts[0].match(/:(.*?);/)?.[1] || 'image/png'
      base64Image = parts[1]
    }

    const prompt = `You are given an image. Determine if the primary object in the image is a ${answer}.

Respond only with the word "true" if the image clearly shows a ${answer}, or "false" if it does not.

Do not provide any explanation, extra words, punctuation, or formatting—only return "true" or "false" in lowercase.`

    console.log('[Content Match] Gemini prompt:', prompt)

    // Fix: Use v1 instead of v1beta and correct model name
    console.log('[Content Match] Calling Gemini API...')
    const response = await fetch(`https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{
          parts: [
            { inlineData: { mimeType, data: base64Image } },
            { text: prompt }
          ]
        }]
      })
    })

    const result = await response.json()
    console.log('[Content Match] Gemini full response:', JSON.stringify(result, null, 2))

    const resultText = result.candidates?.[0]?.content?.parts?.[0]?.text || 'No response'
    console.log('[Content Match] Model response text:', resultText)

    const trimmedResponse = resultText.trim().toLowerCase()
    const matches = trimmedResponse === 'true'

    console.log('[Content Match] Trimmed response:', trimmedResponse)
    console.log('[Content Match] Result:', matches ? 'MATCHES' : 'DOES NOT MATCH')

    return matches
  } catch (error) {
    console.error('[Content Match] Error:', error)
    return false
  }
}

function getFeedback(aiGenerated: boolean, foundOnWeb: boolean, matchesAnswer: boolean, _expectedAnswer: string): string {
  if (aiGenerated) return 'Inauthentic image'
  if (foundOnWeb) return 'Inauthentic image'
  if (!matchesAnswer) return 'Wrong object'
  return 'Valid Image'
}
