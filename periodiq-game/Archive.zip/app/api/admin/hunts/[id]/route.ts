import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'

// Get single hunt
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const supabase = await createClient()

    // Verify admin authentication
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single<{ role: string }>()

    if (!profile || profile.role !== 'admin') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    // Fetch hunt
    const { data: hunt, error } = await supabase
      .from('hunts')
      .select('*')
      .eq('id', id)
      .single()

    if (error || !hunt) {
      return NextResponse.json({ error: 'Hunt not found' }, { status: 404 })
    }

    return NextResponse.json({ hunt })
  } catch (error) {
    console.error('API error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// Update hunt
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const supabase = await createClient()

    // Verify admin authentication
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single<{ role: string }>()

    if (!profile || profile.role !== 'admin') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    // Get request body
    const body = await request.json()
    const {
      title,
      description,
      difficulty,
      duration_minutes,
      start_time,
      end_time,
      status,
      max_participants,
      game_image_url,
      prizes
    } = body

    // Update hunt
    const { data: hunt, error } = await supabase
      .from('hunts')
      // @ts-expect-error - Supabase type inference issue
      .update({
        title,
        description,
        difficulty,
        duration_minutes,
        start_time,
        end_time,
        status,
        max_participants: max_participants || null,
        game_image_url: game_image_url || null,
        prizes: prizes || null
      })
      .eq('id', id)
      .select()
      .single()

    if (error) {
      console.error('Error updating hunt:', error)
      return NextResponse.json({ error: 'Failed to update hunt' }, { status: 500 })
    }

    return NextResponse.json({ hunt })
  } catch (error) {
    console.error('API error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// Delete hunt
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const supabase = await createClient()

    // Verify admin authentication
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single<{ role: string }>()

    if (!profile || profile.role !== 'admin') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    // Delete hunt (cascades to clues, participants, etc.)
    const { error } = await supabase
      .from('hunts')
      .delete()
      .eq('id', id)

    if (error) {
      console.error('Error deleting hunt:', error)
      return NextResponse.json({ error: 'Failed to delete hunt' }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('API error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
