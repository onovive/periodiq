import { NextResponse } from 'next/server';
import OpenAI from 'openai';

function getOpenAIClient() {
  return new OpenAI({
    apiKey: process.env.OPENAI_API_KEY || 'sk-dummy-key-for-build',
  });
}

export async function POST(request: Request) {
  try {
    const { answer, expectedAnswer, validationType, question } = await request.json();

    if (!answer || !expectedAnswer || !validationType) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    let isCorrect = false;
    let feedback = '';

    switch (validationType) {
      case 'exact':
        isCorrect = answer.toLowerCase().trim() === expectedAnswer.toLowerCase().trim();
        feedback = isCorrect
          ? 'Perfect! Your answer matches exactly.'
          : 'Not quite right. Try again!';
        break;

      case 'keyword':
        const keywords = expectedAnswer.toLowerCase().split(',').map((k: string) => k.trim());
        const answerLower = answer.toLowerCase();
        isCorrect = keywords.some((keyword: string) => answerLower.includes(keyword));
        feedback = isCorrect
          ? 'Correct! Your answer contains the key information.'
          : 'Your answer doesn\'t contain the expected keywords. Try again!';
        break;

      case 'ai':
        try {
          if (!process.env.OPENAI_API_KEY) {
            throw new Error('OpenAI API key not configured');
          }
          const client = getOpenAIClient();
          const completion = await client.chat.completions.create({
            model: 'gpt-4o-mini',
            messages: [
              {
                role: 'system',
                content: `You are a helpful assistant evaluating answers to scavenger hunt clues.
                Compare the user's answer with the expected answer and determine if they are semantically equivalent or correct.
                Be lenient with spelling, wording, and formatting differences.
                Respond with a JSON object containing:
                - "isCorrect": boolean indicating if the answer is correct
                - "feedback": string with a brief explanation (1-2 sentences)`
              },
              {
                role: 'user',
                content: `Question: ${question}

Expected Answer: ${expectedAnswer}

User's Answer: ${answer}

Is the user's answer correct? Provide a JSON response.`
              }
            ],
            response_format: { type: 'json_object' },
            temperature: 0.3,
          });

          const result = JSON.parse(completion.choices[0].message.content || '{}');
          isCorrect = result.isCorrect || false;
          feedback = result.feedback || (isCorrect ? 'Correct!' : 'Incorrect answer.');
        } catch (aiError) {
          console.error('OpenAI API error:', aiError);
          // Fallback to keyword matching if AI fails
          const keywords = expectedAnswer.toLowerCase().split(' ').filter((k: string) => k.length > 3);
          const answerLower = answer.toLowerCase();
          isCorrect = keywords.some((keyword: string) => answerLower.includes(keyword));
          feedback = isCorrect
            ? 'Your answer seems correct (AI validation unavailable).'
            : 'Unable to validate with AI. Please try to match the expected answer more closely.';
        }
        break;

      default:
        return NextResponse.json(
          { error: 'Invalid validation type' },
          { status: 400 }
        );
    }

    return NextResponse.json({
      isCorrect,
      feedback,
    });
  } catch (error) {
    console.error('Error validating clue:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
