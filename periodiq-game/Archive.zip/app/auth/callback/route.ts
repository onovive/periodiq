import { createClient } from '@/lib/supabase/server';
import { NextResponse } from 'next/server';

export async function GET(request: Request) {
  const requestUrl = new URL(request.url);
  const code = requestUrl.searchParams.get('code');
  const origin = requestUrl.origin;

  if (code) {
    const supabase = await createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);

    if (!error) {
      const { data: { user } } = await supabase.auth.getUser();

      if (user) {
        // Check if user has completed onboarding
        const { data: profile } = await supabase
          .from('profiles')
          .select('onboarding_completed, display_name, avatar')
          .eq('id', user.id)
          .single<{ onboarding_completed: boolean; display_name: string | null; avatar: string | null }>();

        // If user hasn't completed onboarding, redirect to onboarding
        if (!profile?.onboarding_completed || !profile?.display_name || !profile?.avatar) {
          return NextResponse.redirect(`${origin}/onboarding`);
        }

        // Otherwise redirect to dashboard
        return NextResponse.redirect(`${origin}/dashboard`);
      }
    }
  }

  // If there was an error or no code, redirect to login
  return NextResponse.redirect(`${origin}/login`);
}
