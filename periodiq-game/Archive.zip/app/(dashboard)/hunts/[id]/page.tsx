import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';
import { notFound } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import Header from '@/components/layout/Header';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Link from 'next/link';

interface PageProps {
  params: Promise<{ id: string }>;
}

async function subscribeToHunt(huntId: string) {
  'use server';
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (user) {
    // @ts-expect-error - Supabase type inference issue
    const { error } = await supabase.from('hunt_participants').insert({
      hunt_id: huntId,
      user_id: user.id,
      status: 'subscribed'
    });

    if (error) {
      console.error('Error subscribing to hunt:', error);
      return;
    }

    revalidatePath(`/hunts/${huntId}`);
    revalidatePath('/dashboard');
    redirect(`/hunts/${huntId}`);
  }
}

async function startHunt(participationId: string, huntId: string) {
  'use server';
  const supabase = await createClient();
  // @ts-expect-error - Supabase type inference issue
  const { error } = await supabase.from('hunt_participants').update({
    status: 'active',
    started_at: new Date().toISOString()
  }).eq('id', participationId);

  if (error) {
    console.error('Error starting hunt:', error);
    return;
  }

  revalidatePath(`/hunts/${huntId}`);
  redirect(`/hunts/${huntId}/play`);
}

export default async function HuntDetailsPage({ params }: PageProps) {
  const { id } = await params;
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect('/login');
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('username')
    .eq('id', user.id)
    .single<{ username: string }>();

  // Fetch hunt details
  const { data: hunt, error } = await supabase
    .from('hunts')
    .select('*')
    .eq('id', id)
    .single<any>();

  if (error || !hunt) {
    notFound();
  }

  // Check if user is registered
  const { data: participation } = await supabase
    .from('hunt_participants')
    .select('*')
    .eq('hunt_id', id)
    .eq('user_id', user.id)
    .single<any>();

  // Get participant count
  const { count: participantCount } = await supabase
    .from('hunt_participants')
    .select('*', { count: 'exact', head: true })
    .eq('hunt_id', id);

  // Get clue count
  const { count: clueCount } = await supabase
    .from('clues')
    .select('*', { count: 'exact', head: true })
    .eq('hunt_id', id);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'hard':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  // Time-based validation
  const now = new Date();
  const startTime = new Date(hunt.start_time);
  const endTime = new Date(hunt.end_time);

  const isBeforeStart = now < startTime;
  const isAfterEnd = now > endTime;
  const isWithinTimeWindow = !isBeforeStart && !isAfterEnd;

  const isActive = participation?.status === 'active';
  const isCompleted = participation?.status === 'completed';

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-emerald-50">
      <Header username={profile?.username} />

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <Link
          href="/dashboard"
          className="inline-flex items-center text-emerald-600 hover:text-emerald-700 mb-6"
        >
          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          Back to Dashboard
        </Link>

        <Card padding="lg">
          <div className="mb-6">
            <div className="flex items-start justify-between mb-4">
              <h1 className="text-3xl font-bold text-gray-900">{hunt.title}</h1>
              <span className={`px-3 py-1 rounded-full text-sm font-semibold border ${getDifficultyColor(hunt.difficulty)}`}>
                {hunt.difficulty.toUpperCase()}
              </span>
            </div>
            <p className="text-gray-700 text-lg leading-relaxed">{hunt.description}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="bg-emerald-50 p-4 rounded-lg">
              <div className="flex items-center text-emerald-700">
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span className="font-semibold">Duration</span>
              </div>
              <p className="text-2xl font-bold text-emerald-900 mt-1">{hunt.duration_minutes} min</p>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center text-blue-700">
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
                <span className="font-semibold">Participants</span>
              </div>
              <p className="text-2xl font-bold text-blue-900 mt-1">{participantCount || 0}</p>
            </div>

            <div className="bg-purple-50 p-4 rounded-lg">
              <div className="flex items-center text-purple-700">
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span className="font-semibold">Total Clues</span>
              </div>
              <p className="text-2xl font-bold text-purple-900 mt-1">{clueCount || 0}</p>
            </div>

            <div className="bg-orange-50 p-4 rounded-lg">
              <div className="flex items-center text-orange-700">
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span className="font-semibold">Status</span>
              </div>
              <p className="text-2xl font-bold text-orange-900 mt-1 capitalize">{hunt.status}</p>
            </div>
          </div>

          <div className="space-y-3 mb-6 text-gray-700">
            <div className="flex items-start">
              <svg className="w-5 h-5 mr-3 mt-0.5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              <div>
                <p className="font-semibold">Start Time</p>
                <p>{formatDate(hunt.start_time)}</p>
              </div>
            </div>
            <div className="flex items-start">
              <svg className="w-5 h-5 mr-3 mt-0.5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              <div>
                <p className="font-semibold">End Time</p>
                <p>{formatDate(hunt.end_time)}</p>
              </div>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="font-semibold text-gray-700 mb-3">Prizes</h3>
            <div className="flex gap-3">
              <div className="flex items-center gap-2 bg-gradient-to-r from-yellow-50 to-yellow-100 border border-yellow-300 rounded-lg px-4 py-2 shadow-sm">
                <span className="text-xl">🏆</span>
                <span className="text-sm font-semibold text-yellow-800">1st</span>
              </div>
              <div className="flex items-center gap-2 bg-gradient-to-r from-gray-50 to-gray-100 border border-gray-300 rounded-lg px-4 py-2 shadow-sm">
                <span className="text-xl">🥈</span>
                <span className="text-sm font-semibold text-gray-700">2nd</span>
              </div>
              <div className="flex items-center gap-2 bg-gradient-to-r from-orange-50 to-orange-100 border border-orange-300 rounded-lg px-4 py-2 shadow-sm">
                <span className="text-xl">🥉</span>
                <span className="text-sm font-semibold text-orange-700">3rd</span>
              </div>
            </div>
          </div>

          <div className="border-t pt-6">
            {/* Hunt hasn't started yet */}
            {isBeforeStart && (
              <>
                <div className="text-center bg-yellow-50 p-6 rounded-lg border border-yellow-200 mb-6">
                  <svg className="w-12 h-12 text-yellow-600 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <p className="text-yellow-800 font-semibold text-lg mb-2">Hunt Not Started Yet</p>
                  <p className="text-yellow-700">This hunt will begin at {formatDate(hunt.start_time)}</p>
                  {participation && (
                    <p className="text-yellow-600 mt-2 text-sm">You&apos;re subscribed! Come back when the hunt starts.</p>
                  )}
                </div>

                {/* Show subscribe button if not yet subscribed */}
                {!participation && (
                  <form action={subscribeToHunt.bind(null, id)}>
                    <Button type="submit" fullWidth size="lg">
                      Subscribe to Hunt
                    </Button>
                  </form>
                )}
              </>
            )}

            {/* Hunt has ended */}
            {isAfterEnd && !isCompleted && (
              <div className="text-center bg-red-50 p-6 rounded-lg border border-red-200">
                <svg className="w-12 h-12 text-red-600 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="text-red-800 font-semibold text-lg mb-2">Hunt Has Ended</p>
                <p className="text-red-700">This hunt ended at {formatDate(hunt.end_time)}</p>
              </div>
            )}

            {/* Within time window - show registration or start options */}
            {isWithinTimeWindow && (
              <>
                {!participation && (
                  <form action={subscribeToHunt.bind(null, id)}>
                    <Button type="submit" fullWidth size="lg">
                      Subscribe to Hunt
                    </Button>
                  </form>
                )}

                {participation && !isActive && !isCompleted && (
                  <>
                    <div className="text-center bg-emerald-50 p-4 rounded-lg border border-emerald-200 mb-4">
                      <svg className="w-8 h-8 text-emerald-600 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <p className="text-emerald-800 font-semibold">You&apos;re Subscribed!</p>
                      <p className="text-emerald-700 text-sm mt-1">Ready to start hunting</p>
                    </div>
                    <form action={startHunt.bind(null, participation.id, id)}>
                      <Button type="submit" fullWidth size="lg">
                        Start Hunt Now
                      </Button>
                    </form>
                  </>
                )}

                {isActive && (
                  <Link href={`/hunts/${id}/play`}>
                    <Button fullWidth size="lg">
                      Continue Hunt
                    </Button>
                  </Link>
                )}
              </>
            )}

            {/* Hunt completed by user */}
            {isCompleted && (
              <div className="text-center space-y-4">
                <div className="bg-emerald-50 p-4 rounded-lg">
                  <p className="text-emerald-700 font-semibold text-lg">Hunt Completed!</p>
                  <p className="text-gray-600 mt-1">Your Score: {participation.total_score} points</p>
                </div>
                <Link href={`/hunts/${id}/rankings`}>
                  <Button fullWidth variant="secondary">
                    View Rankings
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </Card>
      </main>
    </div>
  );
}
