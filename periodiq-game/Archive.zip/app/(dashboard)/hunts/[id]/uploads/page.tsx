'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import Button from '@/components/ui/Button';
import { use } from 'react';

interface PageProps {
  params: Promise<{ id: string }>;
}

export default function UploadsReviewPage({ params }: PageProps) {
  const { id } = use(params);
  const router = useRouter();
  const supabase = createClient();

  const [loading, setLoading] = useState(true);
  const [clues, setClues] = useState<any[]>([]);
  const [submissions, setSubmissions] = useState<any[]>([]);

  useEffect(() => {
    loadData();
  }, [id]);

  const loadData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/login');
        return;
      }

      const [cluesRes, participationRes] = await Promise.all([
        supabase.from('clues').select('*').eq('hunt_id', id).order('order_number'),
        supabase
          .from('hunt_participants')
          .select('*')
          .eq('hunt_id', id)
          .eq('user_id', user.id)
          .single<any>(),
      ]);

      if (!participationRes.data) {
        router.push(`/hunts/${id}`);
        return;
      }

      const submissionsRes = await supabase
        .from('submissions')
        .select('*')
        .eq('hunt_participant_id', participationRes.data.id);

      setClues(cluesRes.data || []);
      setSubmissions(submissionsRes.data || []);
      setLoading(false);
    } catch (error) {
      console.error('Error loading data:', error);
      router.push(`/hunts/${id}`);
    }
  };

  const handleCheckResults = () => {
    router.push(`/hunts/${id}/summary`);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-gray-600">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-4">
        <div className="flex items-center">
          <button onClick={() => router.back()} className="p-2 -ml-2">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h1 className="flex-1 text-center font-semibold text-gray-900">YOUR UPLOADS</h1>
          <div className="w-6" /> {/* Spacer */}
        </div>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6">
        {clues.map((clue, index) => {
          const submission = submissions.find(s => s.clue_id === clue.id);
          return (
            <div key={clue.id} className="border-b border-gray-200 pb-6">
              {/* Clue Header */}
              <div className="mb-3">
                <div className="text-sm font-semibold text-gray-900 mb-1">
                  {index + 1}. {clue.question}
                </div>
              </div>

              {/* Image */}
              {submission?.image_url ? (
                <div className="relative">
                  <img
                    src={submission.image_url}
                    alt={`Upload ${index + 1}`}
                    className="w-full rounded-lg"
                  />
                  <button className="absolute bottom-2 right-2 bg-blue-600 text-white px-3 py-1 rounded text-xs font-medium">
                    EDIT
                  </button>
                </div>
              ) : (
                <div className="bg-gray-100 rounded-lg h-48 flex items-center justify-center text-gray-400 text-sm">
                  No photo uploaded
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Fixed Bottom Button */}
      <div className="border-t border-gray-200 px-4 py-4 bg-white">
        <Button onClick={handleCheckResults} fullWidth>
          CHECK RESULTS
        </Button>
      </div>
    </div>
  );
}
