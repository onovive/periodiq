'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import Header from '@/components/layout/Header';
import ClueInterface from '@/components/hunt/ClueInterface';
import HuntTimer from '@/components/hunt/HuntTimer';
import Button from '@/components/ui/Button';
import Spinner from '@/components/ui/Spinner';
import Modal from '@/components/ui/Modal';
import { use } from 'react';

interface PageProps {
  params: Promise<{ id: string }>;
}

export default function PlayHuntPage({ params }: PageProps) {
  const { id } = use(params);
  const router = useRouter();
  const supabase = createClient();

  const [loading, setLoading] = useState(true);
  const [hunt, setHunt] = useState<any>(null);
  const [profile, setProfile] = useState<any>(null);
  const [participation, setParticipation] = useState<any>(null);
  const [clues, setClues] = useState<any[]>([]);
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [currentClueIndex, setCurrentClueIndex] = useState(0);
  const [showSummary, setShowSummary] = useState(false);

  useEffect(() => {
    loadHuntData();
  }, [id]);

  const loadHuntData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/login');
        return;
      }

      const [profileRes, huntRes, participationRes, cluesRes, submissionsRes] = await Promise.all([
        supabase.from('profiles').select('*').eq('id', user.id).single<any>(),
        supabase.from('hunts').select('*').eq('id', id).single<any>(),
        supabase
          .from('hunt_participants')
          .select('*')
          .eq('hunt_id', id)
          .eq('user_id', user.id)
          .single<any>(),
        supabase
          .from('clues')
          .select('*')
          .eq('hunt_id', id)
          .order('order_number', { ascending: true }),
        supabase
          .from('submissions')
          .select('*')
          .eq('hunt_participant_id', (await supabase
            .from('hunt_participants')
            .select('id')
            .eq('hunt_id', id)
            .eq('user_id', user.id)
            .single<{ id: string }>()).data?.id || ''),
      ]);

      if (!huntRes.data || !participationRes.data) {
        router.push('/dashboard');
        return;
      }

      // Time-based validation - check if hunt is within time window
      const now = new Date();
      const startTime = new Date(huntRes.data.start_time);
      const endTime = new Date(huntRes.data.end_time);

      if (now < startTime) {
        alert('This hunt has not started yet. Please wait until the scheduled start time.');
        router.push(`/hunts/${id}`);
        return;
      }

      if (now > endTime) {
        alert('This hunt has ended. You can no longer participate.');
        router.push(`/hunts/${id}`);
        return;
      }

      setProfile(profileRes.data);
      setHunt(huntRes.data);
      setParticipation(participationRes.data);
      setClues(cluesRes.data || []);
      setSubmissions(submissionsRes.data || []);

      // Find the current clue index (first unanswered clue)
      const answeredClueIds = new Set(submissionsRes.data?.map((s: any) => s.clue_id) || []);
      const nextClueIndex = cluesRes.data?.findIndex((c: any) => !answeredClueIds.has(c.id)) || 0;
      setCurrentClueIndex(nextClueIndex >= 0 ? nextClueIndex : cluesRes.data?.length || 0);

      setLoading(false);
    } catch (error) {
      console.error('Error loading hunt data:', error);
      router.push('/dashboard');
    }
  };

  const handleSubmitAnswer = async (answer: string, imageFile?: File) => {
    const currentClue = clues[currentClueIndex];
    if (!currentClue) return { success: false };

    try {
      let imageUrl = '';
      let validation: any;

      // If image file provided, upload it first and then validate with AI
      if (imageFile) {
        // Upload image to Supabase Storage
        const fileExt = imageFile.name.split('.').pop();
        const fileName = `${Math.random().toString(36).substring(2)}_${Date.now()}.${fileExt}`;
        const filePath = `hunt-submissions/${fileName}`;

        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('images')
          .upload(filePath, imageFile);

        if (uploadError) throw uploadError;

        // Get public URL
        const { data: { publicUrl } } = supabase.storage
          .from('images')
          .getPublicUrl(filePath);

        imageUrl = publicUrl;

        // Convert image to base64 for AI validation
        const reader = new FileReader();
        const imageBase64 = await new Promise<string>((resolve) => {
          reader.onloadend = () => resolve(reader.result as string);
          reader.readAsDataURL(imageFile);
        });

        // Call AI validation API
        const response = await fetch('/api/validate-image', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageUrl,
            imageBase64,
            expectedAnswer: currentClue.expected_answer,
          }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || 'Image validation failed');
        }

        validation = await response.json();
      } else {
        // Text-based validation
        const response = await fetch('/api/validate-clue', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            answer,
            expectedAnswer: currentClue.expected_answer,
            validationType: currentClue.validation_type,
            question: currentClue.question,
          }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || 'Answer validation failed');
        }

        validation = await response.json();
      }

      // Map the response to consistent format
      const isCorrect = validation.valid !== undefined ? validation.valid : validation.isCorrect;
      const feedback = validation.feedback;

      // Save submission
      // @ts-expect-error - Supabase type inference issue
      const { error } = await supabase.from('submissions').insert({
        hunt_participant_id: participation.id,
        clue_id: currentClue.id,
        answer: imageFile ? 'image-submission' : answer,
        image_url: imageUrl || null,
        is_correct: isCorrect,
        ai_feedback: feedback,
        points_earned: isCorrect ? currentClue.points : 0,
      });

      if (error) throw error;

      // Update participation score
      if (isCorrect) {
        // @ts-expect-error - Supabase type inference issue
        await supabase.from('hunt_participants').update({ total_score: participation.total_score + currentClue.points }).eq('id', participation.id);

        setParticipation((prev: any) => ({
          ...prev,
          total_score: prev.total_score + currentClue.points,
        }));
      }

      // Reload submissions
      await loadHuntData();

      // Move to next clue if correct
      if (isCorrect && currentClueIndex < clues.length - 1) {
        setTimeout(() => {
          setCurrentClueIndex(currentClueIndex + 1);
        }, 2000);
      } else if (currentClueIndex === clues.length - 1) {
        // Last clue - delay completion to show feedback modal first
        setTimeout(() => {
          handleHuntComplete();
      });
      } 
      
       return {
        success: true,
        isCorrect,
        feedback,
        pointsEarned: isCorrect ? currentClue.points : 0,
        aiGenerated: validation.aiGenerated,
        foundOnWeb: validation.foundOnWeb,
        matchesAnswer: validation.matchesAnswer,
      };
    } catch (error) {
      console.error('Error submitting answer:', error);
      alert(`Error submitting answer: ${error instanceof Error ? error.message : 'Unknown error occurred'}`);
      return { success: false };
    }
  };

  const handleHuntComplete = async () => {
    // @ts-expect-error - Supabase type inference issue
    await supabase.from('hunt_participants').update({ status: 'completed', completed_at: new Date().toISOString() }).eq('id', participation.id);

    // Trigger ranking calculation in background (if hunt has ended + 10 minutes)
    const huntEndTime = new Date(hunt.end_time).getTime();
    const now = Date.now();
    const tenMinutes = 10 * 60 * 1000;

    if (now >= huntEndTime + tenMinutes) {
      // Don't await - let it run in background
      fetch('/api/calculate-rankings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ huntId: id }),
      }).catch(err => console.error('Failed to trigger ranking calculation:', err));
    }

    setShowSummary(true);
  };

  const handleTimeUp = async () => {
    await handleHuntComplete();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-emerald-50 flex items-center justify-center">
        <Spinner size="lg" />
      </div>
    );
  }

  const allCluesAnswered = submissions.length === clues.length;
  const currentClue = clues[currentClueIndex];
  const previousSubmission = submissions.find((s) => s.clue_id === currentClue?.id);

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-emerald-50">
      <Header username={profile?.username} />

      <main className="container mx-auto px-4 py-8 max-w-3xl">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{hunt.title}</h1>
          <p className="text-gray-600">Score: {participation.total_score} points</p>
        </div>

        <div className="mb-6">
          <HuntTimer
            huntStartTime={hunt.start_time}
            durationMinutes={hunt.duration_minutes}
            onTimeUp={handleTimeUp}
          />
        </div>

        {allCluesAnswered ? (
          <div className="text-center bg-white p-8 rounded-xl shadow-md">
            <svg className="w-20 h-20 text-emerald-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Hunt Completed!</h2>
            <p className="text-xl text-gray-700 mb-2">
              Total Score: {participation.total_score} points
            </p>
            <p className="text-gray-600 mb-6">
              You answered all {clues.length} clues!
            </p>
            <Button onClick={() => router.push(`/hunts/${id}/rankings`)}>
              View Rankings
            </Button>
          </div>
        ) : currentClue ? (
          <>
            <ClueInterface
              clue={currentClue}
              clueNumber={currentClueIndex + 1}
              totalClues={clues.length}
              participantId={participation.id}
              previousSubmission={previousSubmission}
              onSubmit={handleSubmitAnswer}
            />

            <div className="flex justify-between items-center mt-4">
              <Button
                variant="outline"
                disabled={currentClueIndex === 0}
                onClick={() => setCurrentClueIndex(Math.max(0, currentClueIndex - 1))}
              >
                Previous Clue
              </Button>
              <Button
                variant="outline"
                disabled={currentClueIndex === clues.length - 1 || !previousSubmission}
                onClick={() => setCurrentClueIndex(Math.min(clues.length - 1, currentClueIndex + 1))}
              >
                Next Clue
              </Button>
            </div>
          </>
        ) : (
          <div className="text-center bg-white p-8 rounded-xl shadow-md">
            <p className="text-gray-600">No clues available</p>
          </div>
        )}
      </main>

      <Modal isOpen={showSummary} onClose={() => router.push(`/hunts/${id}/rankings`)} title="Hunt Complete!">
        <div>
          <div className="text-center mb-6">
            <svg className="w-16 h-16 text-emerald-500 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Congratulations!</h2>
            <p className="text-lg text-gray-700 mb-3">You completed the hunt!</p>
            <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4 inline-block">
              <p className="text-3xl font-bold text-emerald-700">
                {participation.total_score} points
              </p>
              <p className="text-sm text-emerald-600 mt-1">
                {submissions.filter((s) => s.is_correct).length} / {clues.length} correct
              </p>
            </div>
          </div>

          {/* Submission Details */}
          <div className="mb-6 max-h-96 overflow-y-auto">
            <h3 className="font-semibold text-gray-900 mb-3">Your Submissions:</h3>
            <div className="space-y-3">
              {submissions.map((submission: any, index: number) => {
                const clue = clues.find((c: any) => c.id === submission.clue_id);
                return (
                  <div
                    key={submission.id}
                    className={`border-l-4 p-3 rounded-lg text-left ${
                      submission.is_correct
                        ? 'border-emerald-500 bg-emerald-50'
                        : 'border-red-500 bg-red-50'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          {submission.is_correct ? (
                            <svg className="w-4 h-4 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                          ) : (
                            <svg className="w-4 h-4 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                          )}
                          <h4 className="font-semibold text-sm text-gray-900">
                            {clue?.question || `Clue ${index + 1}`}
                          </h4>
                        </div>
                      </div>
                      <p className="text-sm font-bold text-gray-900">
                        {submission.points_earned} / {clue?.points || 0} pts
                      </p>
                    </div>

                    {submission.ai_feedback && (
                      <p className={`text-xs ${submission.is_correct ? 'text-emerald-800' : 'text-red-800'} mb-2`}>
                        {submission.ai_feedback}
                      </p>
                    )}

                    {!submission.is_correct && (
                      <div className="bg-white rounded-lg p-2 mt-2">
                        <p className="text-xs font-semibold text-gray-700 mb-1">Why marks were deducted:</p>
                        <div className="space-y-1 text-xs">
                          {submission.ai_feedback?.includes('AI-generated') && (
                            <div className="flex items-center text-red-700">
                              <span className="mr-1">✗</span>
                              <span>AI-generated image detected</span>
                            </div>
                          )}
                          {submission.ai_feedback?.includes('found on the web') && (
                            <div className="flex items-center text-red-700">
                              <span className="mr-1">✗</span>
                              <span>Image found online</span>
                            </div>
                          )}
                          {submission.ai_feedback?.includes('does not match') && (
                            <div className="flex items-center text-red-700">
                              <span className="mr-1">✗</span>
                              <span>Content doesn't match clue</span>
                            </div>
                          )}
                          {!submission.ai_feedback?.includes('AI-generated') &&
                           !submission.ai_feedback?.includes('found on the web') &&
                           !submission.ai_feedback?.includes('does not match') && (
                            <div className="flex items-center text-red-700">
                              <span className="mr-1">✗</span>
                              <span>Incorrect answer</span>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="border-t pt-4">
            <p className="text-sm text-gray-600 text-center mb-4">
              Rankings will be calculated 10 minutes after the hunt ends.
            </p>
            <Button onClick={() => router.push(`/hunts/${id}/rankings`)} fullWidth>
              View Rankings
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
