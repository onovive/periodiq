import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';
import { notFound } from 'next/navigation';
import Header from '@/components/layout/Header';
import Leaderboard from '@/components/ranking/Leaderboard';
import Card from '@/components/ui/Card';
import Link from 'next/link';

interface PageProps {
  params: Promise<{ id: string }>;
}

export default async function RankingsPage({ params }: PageProps) {
  const { id } = await params;
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect('/login');
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('username')
    .eq('id', user.id)
    .single<{ username: string }>();

  // Fetch hunt details
  const { data: hunt, error } = await supabase
    .from('hunts')
    .select('*')
    .eq('id', id)
    .single<any>();

  if (error || !hunt) {
    notFound();
  }

  // Check if 10 minutes have passed since hunt ended
  const huntEndTime = new Date(hunt.end_time).getTime();
  const now = Date.now();
  const tenMinutes = 10 * 60 * 1000;
  const canShowRankings = now >= huntEndTime + tenMinutes;

  // Fetch rankings if available
  let rankings: any[] = [];
  if (canShowRankings) {
    const { data } = await supabase
      .from('rankings')
      .select(`
        *,
        profiles (
          username,
          avatar_url
        )
      `)
      .eq('hunt_id', id)
      .order('rank', { ascending: true });

    rankings = data || [];

    // If no rankings calculated yet, calculate them
    if (rankings.length === 0) {
      // @ts-expect-error - Supabase RPC type inference issue
      await supabase.rpc('calculate_hunt_rankings', { hunt_id_param: id });

      // Fetch again after calculation
      const { data: newRankings } = await supabase
        .from('rankings')
        .select(`
          *,
          profiles (
            username,
            avatar_url
          )
        `)
        .eq('hunt_id', id)
        .order('rank', { ascending: true });

      rankings = newRankings || [];
    }
  }

  // Get user's participation info
  const { data: participation } = await supabase
    .from('hunt_participants')
    .select('*')
    .eq('hunt_id', id)
    .eq('user_id', user.id)
    .single<any>();

  // Get user's submissions with clue details
  const { data: submissions } = await supabase
    .from('submissions')
    .select(`
      *,
      clues (
        question,
        points,
        order_number
      )
    `)
    .eq('hunt_participant_id', participation?.id || '')
    .order('created_at', { ascending: true });

  const timeUntilRankings = canShowRankings
    ? null
    : new Date(huntEndTime + tenMinutes);

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-emerald-50">
      <Header username={profile?.username} />

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <Link
          href={`/hunts/${id}`}
          className="inline-flex items-center text-emerald-600 hover:text-emerald-700 mb-6"
        >
          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          Back to Hunt Details
        </Link>

        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{hunt.title} - Rankings</h1>
          <p className="text-gray-600">See how you stack up against other participants</p>
        </div>

        {participation && (
          <>
            <Card padding="lg" className="mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Your Performance</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-emerald-50 p-4 rounded-lg">
                  <p className="text-sm text-emerald-700 font-medium mb-1">Status</p>
                  <p className="text-2xl font-bold text-emerald-900 capitalize">
                    {participation.status}
                  </p>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-blue-700 font-medium mb-1">Total Score</p>
                  <p className="text-2xl font-bold text-blue-900">
                    {participation.total_score} pts
                  </p>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg">
                  <p className="text-sm text-purple-700 font-medium mb-1">Completion</p>
                  <p className="text-2xl font-bold text-purple-900">
                    {participation.completed_at ? (
                      <>
                        {new Date(participation.completed_at).toLocaleDateString()}
                      </>
                    ) : (
                      'In Progress'
                    )}
                  </p>
                </div>
              </div>
            </Card>

            {submissions && submissions.length > 0 && (
              <Card padding="lg" className="mb-8">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Your Submissions</h2>
                <p className="text-sm text-gray-600 mb-6">
                  Correct Answers: {submissions.filter((s: any) => s.is_correct).length} / {submissions.length}
                </p>
                <div className="space-y-4">
                  {submissions.map((submission: any, index: number) => (
                    <div
                      key={submission.id}
                      className={`border-l-4 p-4 rounded-lg ${
                        submission.is_correct
                          ? 'border-emerald-500 bg-emerald-50'
                          : 'border-red-500 bg-red-50'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            {submission.is_correct ? (
                              <svg className="w-5 h-5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                              </svg>
                            ) : (
                              <svg className="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                              </svg>
                            )}
                            <h3 className="font-semibold text-gray-900">
                              {submission.clues?.question || `Clue ${index + 1}`}
                            </h3>
                          </div>
                          <p className="text-xs text-gray-500 mb-2">
                            Submitted at {new Date(submission.created_at).toLocaleTimeString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-gray-900">
                            {submission.points_earned} / {submission.clues?.points || 0} pts
                          </p>
                        </div>
                      </div>

                      {submission.image_url && (
                        <img
                          src={submission.image_url}
                          alt="Submission"
                          className="w-32 h-32 object-cover rounded-lg mb-3"
                        />
                      )}

                      {submission.ai_feedback && (
                        <div className="mb-3">
                          <p className={`text-sm ${submission.is_correct ? 'text-emerald-800' : 'text-red-800'}`}>
                            {submission.ai_feedback}
                          </p>
                        </div>
                      )}

                      {!submission.is_correct && submission.image_url && (
                        <div className="bg-white rounded-lg p-3 mt-3">
                          <h4 className="text-xs font-semibold text-gray-700 mb-2">Why marks were deducted:</h4>
                          <div className="space-y-1 text-xs">
                            {submission.ai_feedback?.includes('AI-generated') && (
                              <div className="flex items-center text-red-700">
                                <span className="mr-2">✗</span>
                                <span>Image appears to be AI-generated</span>
                              </div>
                            )}
                            {submission.ai_feedback?.includes('found on the web') && (
                              <div className="flex items-center text-red-700">
                                <span className="mr-2">✗</span>
                                <span>Image found on the web</span>
                              </div>
                            )}
                            {submission.ai_feedback?.includes('does not match') && (
                              <div className="flex items-center text-red-700">
                                <span className="mr-2">✗</span>
                                <span>Image content does not match the clue</span>
                              </div>
                            )}
                            {!submission.ai_feedback?.includes('AI-generated') &&
                             !submission.ai_feedback?.includes('found on the web') &&
                             !submission.ai_feedback?.includes('does not match') && (
                              <div className="flex items-center text-red-700">
                                <span className="mr-2">✗</span>
                                <span>Answer was incorrect</span>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </>
        )}

        <Card padding="lg">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-semibold text-gray-900">Leaderboard</h2>
            {!canShowRankings && timeUntilRankings && (
              <div className="bg-yellow-50 px-3 py-1 rounded-full border border-yellow-200">
                <p className="text-xs text-yellow-800 font-medium">
                  Rankings available on {timeUntilRankings.toLocaleDateString()}
                </p>
              </div>
            )}
          </div>

          {!canShowRankings ? (
            <div className="text-center py-12">
              <svg className="w-20 h-20 text-yellow-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Rankings Coming Soon</h3>
              <p className="text-gray-600 mb-4">
                To ensure fairness, rankings will be calculated and displayed 10 minutes after the hunt ends.
              </p>
              {timeUntilRankings && (
                <p className="text-emerald-600 font-medium">
                  Available on {timeUntilRankings.toLocaleString()}
                </p>
              )}
            </div>
          ) : (
            <Leaderboard rankings={rankings} currentUserId={user.id} />
          )}
        </Card>
      </main>
    </div>
  );
}
