'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import Button from '@/components/ui/Button';
import { use } from 'react';

interface PageProps {
  params: Promise<{ id: string }>;
}

export default function SummaryPage({ params }: PageProps) {
  const { id } = use(params);
  const router = useRouter();
  const supabase = createClient();

  const [loading, setLoading] = useState(true);
  const [clues, setClues] = useState<any[]>([]);
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [timeSpent, setTimeSpent] = useState('00:00:00');
  const [participation, setParticipation] = useState<any>(null);

  useEffect(() => {
    loadData();
  }, [id]);

  const loadData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/login');
        return;
      }

      const participationRes = await supabase
        .from('hunt_participants')
        .select('*')
        .eq('hunt_id', id)
        .eq('user_id', user.id)
        .single<any>();

      if (!participationRes.data) {
        router.push(`/hunts/${id}`);
        return;
      }

      const [cluesRes, submissionsRes] = await Promise.all([
        supabase.from('clues').select('*').eq('hunt_id', id).order('order_number'),
        supabase
          .from('submissions')
          .select('*, clues(question)')
          .eq('hunt_participant_id', participationRes.data.id)
          .order('created_at'),
      ]);

      // Calculate time spent
      if (participationRes.data.started_at && participationRes.data.completed_at) {
        const start = new Date(participationRes.data.started_at).getTime();
        const end = new Date(participationRes.data.completed_at).getTime();
        const diff = end - start;
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);
        setTimeSpent(`${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`);
      }

      setParticipation(participationRes.data);
      setClues(cluesRes.data || []);
      setSubmissions(submissionsRes.data || []);
      setLoading(false);
    } catch (error) {
      console.error('Error loading data:', error);
      router.push(`/hunts/${id}`);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-gray-600">Loading...</div>
      </div>
    );
  }

  const correctCount = submissions.filter(s => s.is_correct).length;
  const totalCount = clues.length;

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-4">
        <div className="flex items-center">
          <button onClick={() => router.back()} className="p-2 -ml-2">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h1 className="flex-1 text-center font-semibold text-gray-900">Hunt Summary</h1>
          <div className="w-6" /> {/* Spacer */}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 py-6">
        {/* Congratulations Header */}
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">CONGRATULATIONS!</h2>

          {/* Stats */}
          <div className="bg-gray-50 rounded-lg p-4 mb-4">
            <div className="flex justify-between items-center mb-3">
              <span className="text-gray-700">Correct Clues:</span>
              <span className="font-bold text-gray-900">{correctCount} / {totalCount}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-700">Time Spent:</span>
              <span className="font-bold text-gray-900">{timeSpent}</span>
            </div>
          </div>
        </div>

        {/* Your findings */}
        <div className="mb-6">
          <h3 className="font-semibold text-gray-900 mb-4">Your findings</h3>
          <div className="space-y-3">
            {submissions.map((submission: any, index: number) => (
              <div
                key={submission.id}
                className={`border-l-4 rounded-lg p-3 ${
                  submission.is_correct
                    ? 'border-green-500 bg-green-50'
                    : 'border-red-400 bg-red-50'
                }`}
              >
                <div className="flex items-start gap-3">
                  {/* Checkmark or X */}
                  <div className="flex-shrink-0 mt-0.5">
                    {submission.is_correct ? (
                      <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    ) : (
                      <svg className="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    )}
                  </div>

                  {/* Content */}
                  <div className="flex-1">
                    <div className="font-medium text-gray-900 text-sm mb-1">
                      {submission.clues?.question || `Clue ${index + 1}`}
                    </div>
                    {submission.ai_feedback && (
                      <div className={`text-xs ${submission.is_correct ? 'text-green-700' : 'text-red-700'}`}>
                        {submission.ai_feedback}
                      </div>
                    )}
                    {submission.created_at && (
                      <div className="text-xs text-gray-500 mt-1">
                        Found at {new Date(submission.created_at).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })}
                      </div>
                    )}
                  </div>

                  {/* Thumbnail */}
                  {submission.image_url && (
                    <div className="flex-shrink-0">
                      <img
                        src={submission.image_url}
                        alt="Submission"
                        className="w-16 h-16 rounded object-cover"
                      />
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Result saved message */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
          <div className="font-semibold text-gray-900 mb-1">Your result has been saved.</div>
          <div className="text-sm text-gray-700">
            The final ranking will be available after the official hunt deadline (in 24 hours).
          </div>
        </div>
      </div>

      {/* Fixed Bottom Button */}
      <div className="border-t border-gray-200 px-4 py-4 bg-white">
        <Button onClick={() => router.push('/dashboard')} fullWidth>
          RETURN TO DASHBOARD
        </Button>
      </div>
    </div>
  );
}
