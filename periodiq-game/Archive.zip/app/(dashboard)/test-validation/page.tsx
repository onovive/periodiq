'use client'

import { useState } from 'react'
import Button from '@/components/ui/Button'
import Input from '@/components/ui/Input'
import Card from '@/components/ui/Card'

export default function TestValidationPage() {
  const [imageUrl, setImageUrl] = useState('')
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [expectedAnswer, setExpectedAnswer] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [previewUrl, setPreviewUrl] = useState('')

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setImageFile(file)
      const reader = new FileReader()
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleTest = async () => {
    if ((!imageUrl && !imageFile) || !expectedAnswer) {
      alert('Please provide an image and expected answer')
      return
    }

    setLoading(true)
    setResult(null)

    try {
      let imageBase64 = ''

      if (imageFile) {
        const reader = new FileReader()
        imageBase64 = await new Promise((resolve) => {
          reader.onloadend = () => resolve(reader.result as string)
          reader.readAsDataURL(imageFile)
        })
      }

      const response = await fetch('/api/validate-image', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          imageUrl: imageUrl || undefined,
          imageBase64: imageBase64 || undefined,
          expectedAnswer,
        }),
      })

      const data = await response.json()
      setResult(data)
    } catch (error) {
      console.error('Error:', error)
      setResult({ error: 'Failed to validate image' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8 max-w-4xl">
      <h1 className="text-3xl font-bold mb-8">Image Validation Test</h1>

      <div className="grid gap-6">
        {/* Input Section */}
        <Card>
          <div className="mb-6">
            <h2 className="text-xl font-semibold">Test Image Validation</h2>
          </div>
          <div className="space-y-4">
            <Input
              label="Image URL (optional)"
              type="text"
              placeholder="https://example.com/image.jpg"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              disabled={!!imageFile}
            />

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Or Upload Image
              </label>
              <input
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                disabled={!!imageUrl}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {previewUrl && (
              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Image Preview
                </label>
                <img
                  src={previewUrl}
                  alt="Preview"
                  className="mt-2 max-w-md rounded-lg border"
                />
              </div>
            )}

            <Input
              label="Expected Answer"
              type="text"
              placeholder="e.g., refrigerator, car, dog"
              value={expectedAnswer}
              onChange={(e) => setExpectedAnswer(e.target.value)}
            />

            <Button onClick={handleTest} disabled={loading} fullWidth loading={loading}>
              Test Validation
            </Button>
          </div>
        </Card>

        {/* Results Section */}
        {result && (
          <Card>
            <div className="mb-6">
              <h2 className="text-xl font-semibold">Validation Results</h2>
            </div>
            <div className="space-y-4">
              {result.error ? (
                <div className="text-red-600 font-semibold">{result.error}</div>
              ) : (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Overall Valid
                      </label>
                      <div className={`text-2xl font-bold ${result.valid ? 'text-green-600' : 'text-red-600'}`}>
                        {result.valid ? '✅ VALID' : '❌ INVALID'}
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Feedback
                      </label>
                      <div className="text-sm">{result.feedback}</div>
                    </div>
                  </div>

                  <div className="border-t pt-4 space-y-2">
                    <h3 className="font-semibold">Detailed Checks:</h3>

                    <div className="flex items-center gap-2">
                      <span className={result.aiGenerated ? 'text-red-600' : 'text-green-600'}>
                        {result.aiGenerated ? '❌' : '✅'}
                      </span>
                      <span>AI Generated Check: {result.aiGenerated ? 'DETECTED' : 'PASSED'}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={result.foundOnWeb ? 'text-red-600' : 'text-green-600'}>
                        {result.foundOnWeb ? '❌' : '✅'}
                      </span>
                      <span>Web Search Check: {result.foundOnWeb ? 'FOUND ON WEB' : 'PASSED'}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={result.matchesAnswer ? 'text-green-600' : 'text-red-600'}>
                        {result.matchesAnswer ? '✅' : '❌'}
                      </span>
                      <span>Content Match: {result.matchesAnswer ? 'MATCHES' : 'DOES NOT MATCH'}</span>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Raw Response
                    </label>
                    <pre className="mt-2 p-4 bg-gray-100 rounded text-xs overflow-auto">
                      {JSON.stringify(result, null, 2)}
                    </pre>
                  </div>
                </>
              )}
            </div>
          </Card>
        )}
      </div>
    </div>
  )
}
