import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';
import Header from '@/components/layout/Header';
import Card from '@/components/ui/Card';

export default async function ProfilePage() {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect('/login');
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single<any>();

  // Get user statistics
  const { data: participations, count: totalHunts } = (await supabase
    .from('hunt_participants')
    .select('*', { count: 'exact' })
    .eq('user_id', user.id)) as { data: any[] | null; count: number | null };

  const completedHunts = participations?.filter((p: any) => p.status === 'completed').length || 0;
  const totalScore = participations?.reduce((sum: number, p: any) => sum + p.total_score, 0) || 0;

  // Get recent participations
  const { data: recentParticipations } = (await supabase
    .from('hunt_participants')
    .select(`
      *,
      hunts (
        id,
        title,
        difficulty
      )
    `)
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(5)) as { data: any[] | null };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-emerald-50">
      <Header username={profile?.username} />

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">My Profile</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card padding="lg">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Profile Information</h2>
            <div className="space-y-3">
              <div>
                <p className="text-sm text-gray-600">Username</p>
                <p className="text-lg font-medium text-gray-900">{profile?.username}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Email</p>
                <p className="text-lg font-medium text-gray-900">{user.email}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Member Since</p>
                <p className="text-lg font-medium text-gray-900">
                  {new Date(profile?.created_at || '').toLocaleDateString()}
                </p>
              </div>
            </div>
          </Card>

          <Card padding="lg">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Statistics</h2>
            <div className="space-y-4">
              <div className="bg-emerald-50 p-4 rounded-lg">
                <p className="text-sm text-emerald-700 font-medium">Total Hunts</p>
                <p className="text-3xl font-bold text-emerald-900">{totalHunts || 0}</p>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm text-blue-700 font-medium">Completed</p>
                <p className="text-3xl font-bold text-blue-900">{completedHunts}</p>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg">
                <p className="text-sm text-purple-700 font-medium">Total Score</p>
                <p className="text-3xl font-bold text-purple-900">{totalScore}</p>
              </div>
            </div>
          </Card>
        </div>

        <Card padding="lg">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Hunt Activity</h2>
          {recentParticipations && recentParticipations.length > 0 ? (
            <div className="space-y-3">
              {recentParticipations.map((participation: any) => (
                <div
                  key={participation.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <div>
                    <h3 className="font-semibold text-gray-900">
                      {participation.hunts?.title || 'Unknown Hunt'}
                    </h3>
                    <p className="text-sm text-gray-600 capitalize">
                      Status: {participation.status} • Score: {participation.total_score}
                    </p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    participation.hunts?.difficulty === 'easy'
                      ? 'bg-green-100 text-green-800'
                      : participation.hunts?.difficulty === 'medium'
                      ? 'bg-yellow-100 text-yellow-800'
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {participation.hunts?.difficulty}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-600 text-center py-8">
              No hunt activity yet. Start by joining a hunt!
            </p>
          )}
        </Card>
      </main>
    </div>
  );
}
