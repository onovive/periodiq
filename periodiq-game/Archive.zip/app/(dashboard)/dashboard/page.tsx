import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';
import Header from '@/components/layout/Header';
import HuntList from '@/components/hunt/HuntList';

export default async function DashboardPage() {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect('/login');
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('username')
    .eq('id', user.id)
    .single<{ username: string }>();

  // Fetch all hunts with participant counts
  const { data: hunts } = await supabase
    .from('hunts')
    .select(`
      *,
      hunt_participants (
        id,
        user_id
      )
    `)
    .order('start_time', { ascending: true });

  // Transform data to include participant count and user registration status
  const now = new Date();
  const huntsWithStats = hunts?.map((hunt: any) => {
    const startTime = new Date(hunt.start_time);
    const endTime = new Date(hunt.end_time);

    // Determine actual status based on current time
    let actualStatus = hunt.status;
    if (now < startTime) {
      actualStatus = 'upcoming';
    } else if (now > endTime) {
      actualStatus = 'completed';
    } else {
      actualStatus = 'active';
    }

    return {
      ...hunt,
      status: actualStatus, // Override with time-based status
      participant_count: hunt.hunt_participants?.length || 0,
      user_subscribed: hunt.hunt_participants?.some((p: any) => p.user_id === user.id),
      hunt_participants: undefined, // Remove the raw data
    };
  }) || [];

  // Separate and sort hunts: upcoming first (earliest first), then active, then past (most recent first)
  const upcomingHunts = huntsWithStats.filter((h: any) => h.status === 'upcoming');
  const activeHunts = huntsWithStats.filter((h: any) => h.status === 'active');
  const pastHunts = huntsWithStats.filter((h: any) => h.status === 'completed').reverse();
  const sortedHunts = [...upcomingHunts, ...activeHunts, ...pastHunts];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header username={profile?.username} />

      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {/* Hunt List */}
        <HuntList hunts={sortedHunts} />
      </main>
    </div>
  );
}
