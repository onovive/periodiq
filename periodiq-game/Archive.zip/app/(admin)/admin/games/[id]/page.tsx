import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import Card from '@/components/ui/Card'
import Badge from '@/components/ui/Badge'
import Button from '@/components/ui/Button'
import Table, { TableColumn } from '@/components/ui/Table'

export default async function GameDetailsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const supabase = await createClient()

  // Verify admin access
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) {
    redirect('/login')
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single<{ role: string }>()

  if (!profile || profile.role !== 'admin') {
    redirect('/dashboard')
  }

  // Fetch hunt details
  const { data: hunt } = await supabase
    .from('hunts')
    .select(`
      *,
      profiles!created_by(username)
    `)
    .eq('id', id)
    .single<{
      id: string
      title: string
      description: string
      difficulty: string
      status: string
      start_time: string
      end_time: string
      duration_minutes: number
      max_participants: number | null
      created_by: string
      created_at: string
      updated_at: string
      profiles: { username: string } | null
    }>()

  if (!hunt) {
    return <div className="text-center py-12 text-gray-600">Hunt not found</div>
  }

  // Fetch participants
  const { data: participants } = await supabase
    .from('hunt_participants')
    .select(`
      *,
      profiles(username, avatar_url)
    `)
    .eq('hunt_id', id)
    .order('created_at', { ascending: false })
    .returns<Array<{
      id: string
      hunt_id: string
      user_id: string
      status: string
      total_score: number
      started_at: string | null
      completed_at: string | null
      created_at: string
      profiles: { username: string; avatar_url: string | null }
    }>>()

  // Fetch clues count
  const { count: clueCount } = await supabase
    .from('clues')
    .select('*', { count: 'exact', head: true })
    .eq('hunt_id', id)

  const columns: TableColumn[] = [
    {
      key: 'username',
      label: 'User',
      render: (_: any, row: any) => row.profiles.username
    },
    {
      key: 'status',
      label: 'Status',
      render: (value: string) => (
        <Badge variant={
          value === 'completed' ? 'success' :
          value === 'active' ? 'info' :
          'default'
        }>
          {value.toUpperCase()}
        </Badge>
      )
    },
    {
      key: 'total_score',
      label: 'Score',
      render: (value: number) => value || 0
    },
    {
      key: 'started_at',
      label: 'Started',
      render: (value: string) => value ? new Date(value).toLocaleString() : '-'
    },
    {
      key: 'completed_at',
      label: 'Completed',
      render: (value: string) => value ? new Date(value).toLocaleString() : '-'
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">{hunt.title}</h1>
          <p className="text-gray-600 mt-1">Game Details & Participants</p>
        </div>
        <div className="flex gap-3">
          <Link href="/admin/games">
            <Button variant="outline">Back to Games</Button>
          </Link>
          <Link href={`/admin/games/${id}/edit`}>
            <Button variant="outline">Edit</Button>
          </Link>
          <Link href={`/admin/games/${id}/clues`}>
            <Button>Manage Clues</Button>
          </Link>
        </div>
      </div>

      {/* Hunt Info Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card padding="lg">
          <p className="text-sm text-gray-600 mb-1">Status</p>
          <Badge variant={
            hunt.status === 'active' ? 'success' :
            hunt.status === 'upcoming' ? 'info' :
            'default'
          }>
            {hunt.status.toUpperCase()}
          </Badge>
        </Card>

        <Card padding="lg">
          <p className="text-sm text-gray-600 mb-1">Difficulty</p>
          <p className="text-xl font-bold text-gray-900">{hunt.difficulty}</p>
        </Card>

        <Card padding="lg">
          <p className="text-sm text-gray-600 mb-1">Duration</p>
          <p className="text-xl font-bold text-gray-900">{hunt.duration_minutes} min</p>
        </Card>

        <Card padding="lg">
          <p className="text-sm text-gray-600 mb-1">Participants</p>
          <p className="text-xl font-bold text-gray-900">{participants?.length || 0}</p>
        </Card>
      </div>

      {/* Hunt Details */}
      <Card padding="lg">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Hunt Information</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-gray-600">Description</p>
            <p className="font-medium text-gray-900">{hunt.description}</p>
          </div>
          <div>
            <p className="text-gray-600">Created By</p>
            <p className="font-medium text-gray-900">{hunt.profiles?.username || 'Unknown'}</p>
          </div>
          <div>
            <p className="text-gray-600">Start Time</p>
            <p className="font-medium text-gray-900">{new Date(hunt.start_time).toLocaleString()}</p>
          </div>
          <div>
            <p className="text-gray-600">End Time</p>
            <p className="font-medium text-gray-900">{new Date(hunt.end_time).toLocaleString()}</p>
          </div>
          <div>
            <p className="text-gray-600">Total Clues</p>
            <p className="font-medium text-gray-900">{clueCount || 0}</p>
          </div>
          <div>
            <p className="text-gray-600">Max Participants</p>
            <p className="font-medium text-gray-900">{hunt.max_participants || 'Unlimited'}</p>
          </div>
        </div>
      </Card>

      {/* Participants Table */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Registered Participants</h2>
        <Card padding="none">
          <Table
            columns={columns}
            data={participants || []}
            emptyMessage="No participants yet"
          />
        </Card>
      </div>
    </div>
  )
}
