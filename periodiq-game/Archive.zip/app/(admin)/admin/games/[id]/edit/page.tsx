'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import HuntForm from '@/components/admin/HuntForm'
import Card from '@/components/ui/Card'
import Spinner from '@/components/ui/Spinner'

export default function EditGamePage({ params }: { params: Promise<{ id: string }> }) {
  const router = useRouter()
  const [hunt, setHunt] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [huntId, setHuntId] = useState<string>('')

  useEffect(() => {
    const initParams = async () => {
      const resolvedParams = await params
      setHuntId(resolvedParams.id)
    }
    initParams()
  }, [params])

  useEffect(() => {
    if (huntId) {
      fetchHunt()
    }
  }, [huntId])

  const fetchHunt = async () => {
    const supabase = createClient()
    const { data } = await supabase
      .from('hunts')
      .select('*')
      .eq('id', huntId)
      .single<any>()

    if (data) {
      // Convert UTC time to local datetime-local format (YYYY-MM-DDTHH:mm)
      const startDate = new Date(data.start_time)
      const localStartTime = new Date(startDate.getTime() - startDate.getTimezoneOffset() * 60000)
        .toISOString()
        .slice(0, 16)

      setHunt({
        ...data,
        start_time: localStartTime
      })
    }
    setLoading(false)
  }

  const handleSubmit = async (formData: any) => {
    try {
      // Convert local datetime to ISO string (UTC)
      const startTime = new Date(formData.startTime)
      const endTime = new Date(startTime.getTime() + formData.durationMinutes * 60000)

      const response = await fetch(`/api/admin/hunts/${huntId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: formData.title,
          description: formData.description,
          difficulty: formData.difficulty,
          duration_minutes: formData.durationMinutes,
          start_time: startTime.toISOString(),
          end_time: endTime.toISOString(),
          status: formData.status,
          max_participants: formData.maxParticipants || null,
          game_image_url: formData.gameImageUrl || null,
          prizes: formData.prizes || null
        })
      })

      if (!response.ok) {
        throw new Error('Failed to update hunt')
      }

      router.push('/admin/games')
    } catch (error: any) {
      alert(error.message || 'Failed to update hunt')
      throw error
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Spinner size="lg" color="primary" />
      </div>
    )
  }

  if (!hunt) {
    return <div className="text-center py-12 text-gray-600">Hunt not found</div>
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Edit Game</h1>
        <p className="text-gray-600 mt-1">Update hunt details</p>
      </div>

      <Card padding="lg">
        <HuntForm
          initialData={{
            title: hunt.title,
            description: hunt.description,
            difficulty: hunt.difficulty,
            startTime: hunt.start_time,
            durationMinutes: hunt.duration_minutes,
            maxParticipants: hunt.max_participants,
            status: hunt.status,
            gameImageUrl: hunt.game_image_url,
            prizes: hunt.prizes || []
          }}
          onSubmit={handleSubmit}
          onCancel={() => router.push('/admin/games')}
          submitLabel="Update Hunt"
        />
      </Card>
    </div>
  )
}
