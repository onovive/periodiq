'use client'

import { use, useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import ClueForm from '@/components/admin/ClueForm'
import Card from '@/components/ui/Card'
import Button from '@/components/ui/Button'
import Badge from '@/components/ui/Badge'
import Modal from '@/components/ui/Modal'
import Spinner from '@/components/ui/Spinner'

interface Clue {
  id: string
  order_number: number
  question: string
  hint?: string
  expected_answer: string
  answer_type: string
  validation_type: string
  points: number
}

interface Hunt {
  id: string
  title: string
  difficulty: string
  status: string
}

export default function ManageCluesPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const router = useRouter()
  const [hunt, setHunt] = useState<Hunt | null>(null)
  const [clues, setClues] = useState<Clue[]>([])
  const [loading, setLoading] = useState(true)
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [editingClue, setEditingClue] = useState<Clue | null>(null)
  const [deleteClueId, setDeleteClueId] = useState<string | null>(null)

  useEffect(() => {
    fetchData()
  }, [id])

  const fetchData = async () => {
    const supabase = createClient()

    // Fetch hunt
    const { data: huntData } = await supabase
      .from('hunts')
      .select('id, title, difficulty, status')
      .eq('id', id)
      .single()

    if (huntData) setHunt(huntData)

    // Fetch clues
    const { data: cluesData } = await supabase
      .from('clues')
      .select('*')
      .eq('hunt_id', id)
      .order('order_number', { ascending: true })

    if (cluesData) setClues(cluesData)
    setLoading(false)
  }

  const handleSubmitClue = async (formData: any) => {
    console.log('handleSubmitClue: called with formData =', formData)
    const supabase = createClient()

    if (editingClue) {
      console.log('handleSubmitClue: updating existing clue')
      // Update existing clue
      const { error } = await supabase
        .from('clues')
        // @ts-expect-error - Supabase type inference issue with client
        .update({
          order_number: formData.orderNumber,
          question: formData.question,
          hint: formData.hint || null,
          expected_answer: formData.expectedAnswer,
          answer_type: formData.answerType,
          validation_type: formData.validationType,
          points: formData.points
        })
        .eq('id', editingClue.id)

      if (error) {
        console.error('handleSubmitClue: update error =', error)
        throw error
      }
      console.log('handleSubmitClue: update successful')
    } else {
      console.log('handleSubmitClue: creating new clue for hunt_id =', id)
      // Create new clue
      const { data, error } = await supabase
        .from('clues')
        // @ts-expect-error - Supabase type inference issue with client
        .insert({
          hunt_id: id,
          order_number: formData.orderNumber,
          question: formData.question,
          hint: formData.hint || null,
          expected_answer: formData.expectedAnswer,
          answer_type: formData.answerType,
          validation_type: formData.validationType,
          points: formData.points
        })

      console.log('handleSubmitClue: insert result =', { data, error })
      if (error) {
        console.error('handleSubmitClue: insert error =', error)
        throw error
      }
      console.log('handleSubmitClue: insert successful')
    }

    console.log('handleSubmitClue: closing form and refreshing data')
    setIsFormOpen(false)
    setEditingClue(null)
    fetchData()
  }

  const handleDeleteClue = async () => {
    if (!deleteClueId) return

    const supabase = createClient()
    const { error } = await supabase
      .from('clues')
      .delete()
      .eq('id', deleteClueId)

    if (error) {
      alert('Failed to delete clue')
      return
    }

    setDeleteClueId(null)
    fetchData()
  }

  const moveClue = async (clueId: string, direction: 'up' | 'down') => {
    const currentIndex = clues.findIndex(c => c.id === clueId)
    if (currentIndex === -1) return

    const targetIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1
    if (targetIndex < 0 || targetIndex >= clues.length) return

    const newClues = [...clues]
    const temp = newClues[currentIndex]
    newClues[currentIndex] = newClues[targetIndex]
    newClues[targetIndex] = temp

    // Update order numbers
    const supabase = createClient()
    await Promise.all(
      newClues.map((clue, index) =>
        supabase
          .from('clues')
          // @ts-expect-error - Supabase type inference issue with client
          .update({ order_number: index + 1 })
          .eq('id', clue.id)
      )
    )

    fetchData()
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Spinner size="lg" color="primary" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Manage Clues</h1>
          <p className="text-gray-600 mt-1">
            {hunt?.title} • {clues.length} clue{clues.length !== 1 ? 's' : ''}
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={() => router.push('/admin/games')}>
            Back to Games
          </Button>
          <Button onClick={() => {
            setEditingClue(null)
            setIsFormOpen(true)
          }}>
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Add Clue
          </Button>
        </div>
      </div>

      {/* Clues List */}
      <div className="space-y-4">
        {clues.length === 0 ? (
          <Card padding="lg">
            <div className="text-center py-12">
              <svg className="w-12 h-12 mx-auto text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No clues yet</h3>
              <p className="text-gray-600 mb-4">Add your first clue to get started</p>
              <Button onClick={() => setIsFormOpen(true)}>Add First Clue</Button>
            </div>
          </Card>
        ) : (
          clues.map((clue, index) => (
            <Card key={clue.id} padding="lg" hover>
              <div className="flex items-start gap-4">
                {/* Order Number */}
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center">
                    <span className="text-emerald-600 font-bold">#{clue.order_number}</span>
                  </div>
                </div>

                {/* Clue Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-4 mb-2">
                    <div className="flex-1">
                      <p className="font-medium text-gray-900 mb-1">{clue.question}</p>
                      {clue.hint && (
                        <p className="text-sm text-gray-600">
                          <span className="font-medium">Hint:</span> {clue.hint}
                        </p>
                      )}
                    </div>
                    <div className="flex gap-2 flex-shrink-0">
                      <Badge variant={
                        clue.validation_type === 'ai' ? 'info' :
                        clue.validation_type === 'exact' ? 'success' :
                        'warning'
                      }>
                        {clue.validation_type.toUpperCase()}
                      </Badge>
                      <Badge>{clue.points} pts</Badge>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600">
                    <span className="font-medium">Expected:</span> {clue.expected_answer}
                  </p>
                </div>

                {/* Actions */}
                <div className="flex flex-col gap-2">
                  <div className="flex gap-1">
                    <button
                      onClick={() => moveClue(clue.id, 'up')}
                      disabled={index === 0}
                      className="p-1 text-gray-400 hover:text-gray-600 disabled:opacity-30"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
                      </svg>
                    </button>
                    <button
                      onClick={() => moveClue(clue.id, 'down')}
                      disabled={index === clues.length - 1}
                      className="p-1 text-gray-400 hover:text-gray-600 disabled:opacity-30"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </button>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setEditingClue(clue)
                      setIsFormOpen(true)
                    }}
                  >
                    Edit
                  </Button>
                  <Button
                    size="sm"
                    variant="danger"
                    onClick={() => setDeleteClueId(clue.id)}
                  >
                    Delete
                  </Button>
                </div>
              </div>
            </Card>
          ))
        )}
      </div>

      {/* Add/Edit Clue Modal */}
      <Modal
        isOpen={isFormOpen}
        onClose={() => {
          setIsFormOpen(false)
          setEditingClue(null)
        }}
        title={editingClue ? 'Edit Clue' : 'Add New Clue'}
        size="lg"
      >
        <ClueForm
          huntId={id}
          initialData={editingClue || undefined}
          nextOrderNumber={clues.length + 1}
          onSubmit={handleSubmitClue}
          onCancel={() => {
            setIsFormOpen(false)
            setEditingClue(null)
          }}
          submitLabel={editingClue ? 'Update Clue' : 'Add Clue'}
        />
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={!!deleteClueId}
        onClose={() => setDeleteClueId(null)}
        title="Delete Clue"
      >
        <div className="space-y-4">
          <p className="text-gray-700">
            Are you sure you want to delete this clue? This action cannot be undone.
          </p>
          <div className="flex gap-3">
            <Button variant="danger" onClick={handleDeleteClue} fullWidth>
              Delete Clue
            </Button>
            <Button variant="outline" onClick={() => setDeleteClueId(null)} fullWidth>
              Cancel
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}
