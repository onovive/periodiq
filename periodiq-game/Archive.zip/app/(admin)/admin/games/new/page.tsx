'use client'

import { useRouter } from 'next/navigation'
import HuntForm from '@/components/admin/HuntForm'
import Card from '@/components/ui/Card'

export default function NewGamePage() {
  const router = useRouter()

  const handleSubmit = async (formData: any) => {
    try {
      // Convert local datetime to ISO string (UTC)
      const startTime = new Date(formData.startTime)
      const endTime = new Date(startTime.getTime() + formData.durationMinutes * 60000)

      const response = await fetch('/api/admin/hunts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: formData.title,
          description: formData.description,
          difficulty: formData.difficulty,
          duration_minutes: formData.durationMinutes,
          start_time: startTime.toISOString(),
          end_time: endTime.toISOString(),
          status: formData.status,
          max_participants: formData.maxParticipants || null,
          game_image_url: formData.gameImageUrl || null,
          prizes: formData.prizes || null
        })
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.message || 'Failed to create hunt')
      }

      const { hunt } = await response.json()

      // Redirect to clues management for the new hunt
      router.push(`/admin/games/${hunt.id}/clues`)
    } catch (error: any) {
      alert(error.message || 'Failed to create hunt')
      throw error
    }
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Create New Game</h1>
        <p className="text-gray-600 mt-1">Set up a new scavenger hunt for your users</p>
      </div>

      <Card padding="lg">
        <HuntForm
          onSubmit={handleSubmit}
          onCancel={() => router.push('/admin/games')}
          submitLabel="Create Hunt"
        />
      </Card>
    </div>
  )
}
