import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import GamesTable from '@/components/admin/GamesTable'
import Button from '@/components/ui/Button'

export default async function AdminGamesPage() {
  const supabase = await createClient()

  // Verify admin access
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) {
    redirect('/login')
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single<{ role: string }>()

  if (!profile || profile.role !== 'admin') {
    redirect('/dashboard')
  }

  // Fetch all hunts with participant counts and clue counts
  const { data: hunts } = (await supabase
    .from('hunts')
    .select(`
      *,
      hunt_participants(count),
      clues(count),
      profiles!created_by(username)
    `)
    .order('created_at', { ascending: false })) as { data: any[] | null }

  // Transform data for easier use
  const huntsWithCounts = hunts?.map((hunt: any) => ({
    ...hunt,
    participant_count: hunt.hunt_participants?.[0]?.count || 0,
    clue_count: hunt.clues?.[0]?.count || 0,
    created_by_username: hunt.profiles?.username || 'Unknown'
  })) || []

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Games Management</h1>
          <p className="text-gray-600 mt-1">Create and manage scavenger hunts</p>
        </div>
        <Link href="/admin/games/new">
          <Button>
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Create New Game
          </Button>
        </Link>
      </div>

      <GamesTable hunts={huntsWithCounts} />
    </div>
  )
}
