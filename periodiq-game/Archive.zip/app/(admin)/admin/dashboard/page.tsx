import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import AnalyticsCard from '@/components/admin/AnalyticsCard'

export default async function AdminDashboardPage() {
  const supabase = await createClient()

  // Verify user is admin
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) {
    redirect('/login')
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single<{ role: string }>()

  if (!profile || profile.role !== 'admin') {
    redirect('/dashboard')
  }

  // Fetch statistics
  const { count: totalUsers } = await supabase
    .from('profiles')
    .select('*', { count: 'exact', head: true })

  const { count: totalHunts } = await supabase
    .from('hunts')
    .select('*', { count: 'exact', head: true })

  const { count: activeHunts } = await supabase
    .from('hunts')
    .select('*', { count: 'exact', head: true })
    .eq('status', 'active')

  const { count: totalParticipations } = await supabase
    .from('hunt_participants')
    .select('*', { count: 'exact', head: true })

  const { count: completedHunts } = await supabase
    .from('hunt_participants')
    .select('*', { count: 'exact', head: true })
    .eq('status', 'completed')

  // Fetch recent hunts
  const { data: recentHunts } = await supabase
    .from('hunts')
    .select('id, title, status, created_at')
    .order('created_at', { ascending: false })
    .limit(5)
    .returns<Array<{ id: string; title: string; status: string; created_at: string }>>()

  // Fetch recent users
  const { data: recentUsers } = await supabase
    .from('profiles')
    .select('id, username, created_at')
    .order('created_at', { ascending: false })
    .limit(5)
    .returns<Array<{ id: string; username: string; created_at: string }>>()

  return (
    <div className="space-y-10">
      <div>
        <h1 className="text-4xl font-bold text-gray-900">Admin Dashboard</h1>
        <p className="text-gray-600 mt-2 text-lg">Overview of your PeriodIQ platform</p>
      </div>

      {/* Analytics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-7">
        <AnalyticsCard
          title="Total Users"
          value={totalUsers || 0}
          color="emerald"
          icon={
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
            </svg>
          }
        />

        <AnalyticsCard
          title="Total Hunts"
          value={totalHunts || 0}
          color="blue"
          icon={
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          }
        />

        <AnalyticsCard
          title="Active Hunts"
          value={activeHunts || 0}
          color="yellow"
          icon={
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          }
        />

        <AnalyticsCard
          title="Participations"
          value={totalParticipations || 0}
          color="purple"
          description={`${completedHunts || 0} completed`}
          icon={
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
          }
        />
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-7">
        {/* Recent Hunts */}
        <div className="bg-white rounded-2xl shadow-md border border-gray-200 p-7">
          <h2 className="text-xl font-bold text-gray-900 mb-5">Recent Hunts</h2>
          <div className="space-y-3">
            {recentHunts && recentHunts.length > 0 ? (
              recentHunts.map((hunt) => (
                <div
                  key={hunt.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 hover:shadow-sm transition-all"
                >
                  <div>
                    <p className="font-semibold text-gray-900 mb-1">{hunt.title}</p>
                    <p className="text-sm text-gray-500">
                      {new Date(hunt.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  <span
                    className={`px-3 py-1.5 text-xs font-bold rounded-full shadow-sm ${
                      hunt.status === 'active'
                        ? 'bg-emerald-100 text-emerald-800'
                        : hunt.status === 'upcoming'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}
                  >
                    {hunt.status}
                  </span>
                </div>
              ))
            ) : (
              <p className="text-gray-500 text-center py-4">No hunts yet</p>
            )}
          </div>
        </div>

        {/* Recent Users */}
        <div className="bg-white rounded-2xl shadow-md border border-gray-200 p-7">
          <h2 className="text-xl font-bold text-gray-900 mb-5">Recent Users</h2>
          <div className="space-y-3">
            {recentUsers && recentUsers.length > 0 ? (
              recentUsers.map((user) => (
                <div
                  key={user.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 hover:shadow-sm transition-all"
                >
                  <div>
                    <p className="font-semibold text-gray-900 mb-1">{user.username}</p>
                    <p className="text-sm text-gray-500">
                      Joined {new Date(user.created_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-gray-500 text-center py-4">No users yet</p>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
