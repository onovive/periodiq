import RegisterForm from '@/components/auth/RegisterForm';
import Card from '@/components/ui/Card';

export default function RegisterPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-50 to-white p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-emerald-600 mb-2">PeriodiQ</h1>
          <p className="text-gray-600">Create an account to start your hunting journey.</p>
        </div>

        <Card padding="lg">
          <h2 className="text-2xl font-semibold text-gray-900 mb-6">Create Account</h2>
          <RegisterForm />
        </Card>
      </div>
    </div>
  );
}
