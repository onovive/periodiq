import OnboardingForm from '@/components/auth/OnboardingForm';
import Card from '@/components/ui/Card';
import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';

export default async function OnboardingPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    redirect('/login');
  }

  // Check if already onboarded
  const { data: profile } = await supabase
    .from('profiles')
    .select('onboarding_completed, display_name, avatar')
    .eq('id', user.id)
    .single<{ onboarding_completed: boolean; display_name: string | null; avatar: string | null }>();

  if (profile?.onboarding_completed && profile?.display_name && profile?.avatar) {
    redirect('/dashboard');
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-50 to-white p-4">
      <div className="w-full max-w-2xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-emerald-600 mb-2">PeriodiQ</h1>
          <p className="text-gray-600">Complete your profile to start playing</p>
        </div>

        <Card padding="lg">
          <OnboardingForm userId={user.id} />
        </Card>
      </div>
    </div>
  );
}
