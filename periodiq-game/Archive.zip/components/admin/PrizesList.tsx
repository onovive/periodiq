'use client'

import { useState } from 'react'
import Input from '../ui/Input'
import Button from '../ui/Button'

interface PrizesListProps {
  prizes: string[]
  onChange: (prizes: string[]) => void
}

export default function PrizesList({ prizes, onChange }: PrizesListProps) {
  const [newPrize, setNewPrize] = useState('')

  const handleAdd = () => {
    if (newPrize.trim()) {
      onChange([...prizes, newPrize.trim()])
      setNewPrize('')
    }
  }

  const handleRemove = (index: number) => {
    onChange(prizes.filter((_, i) => i !== index))
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      handleAdd()
    }
  }

  return (
    <div className="space-y-4">
      <label className="block text-sm font-semibold text-gray-700">
        Prizes & Rewards
      </label>
      <p className="text-sm text-gray-500">
        Add the prizes that participants can win in this hunt
      </p>

      {/* Prize List */}
      {prizes.length > 0 && (
        <div className="space-y-2">
          {prizes.map((prize, index) => (
            <div
              key={index}
              className="flex items-center gap-3 p-3 bg-gradient-to-r from-emerald-50 to-white border border-emerald-200 rounded-lg group hover:shadow-md transition-all"
            >
              <div className="flex items-center gap-2 flex-1">
                <span className="text-xl">
                  {index === 0 ? '🏆' : index === 1 ? '🥈' : index === 2 ? '🥉' : '🎁'}
                </span>
                <span className="text-gray-900 font-medium">{prize}</span>
              </div>
              <button
                type="button"
                onClick={() => handleRemove(index)}
                className="opacity-0 group-hover:opacity-100 transition-opacity bg-red-500 hover:bg-red-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold"
              >
                ×
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Add Prize Input */}
      <div className="flex gap-2">
        <Input
          value={newPrize}
          onChange={(e) => setNewPrize(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="e.g., $100 Cash Prize, VIP Pass, Free Tickets"
          className="flex-1"
        />
        <Button
          type="button"
          variant="secondary"
          onClick={handleAdd}
          disabled={!newPrize.trim()}
        >
          Add Prize
        </Button>
      </div>

      {prizes.length === 0 && (
        <p className="text-sm text-gray-400 italic text-center py-4 border-2 border-dashed border-gray-200 rounded-lg">
          No prizes added yet. Add prizes to make your hunt more exciting!
        </p>
      )}
    </div>
  )
}
