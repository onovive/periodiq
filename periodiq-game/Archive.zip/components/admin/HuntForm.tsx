'use client'

import { useState } from 'react'
import Input from '../ui/Input'
import Textarea from '../ui/Textarea'
import Select from '../ui/Select'
import DateTimeInput from '../ui/DateTimeInput'
import Button from '../ui/Button'
import ImageUpload from '../ui/ImageUpload'
import PrizesList from './PrizesList'

interface HuntFormData {
  title: string
  description: string
  difficulty: 'easy' | 'medium' | 'hard'
  startTime: string
  durationMinutes: number
  maxParticipants?: number
  status: 'upcoming' | 'active' | 'completed'
  gameImageUrl?: string
  prizes?: string[]
}

interface HuntFormProps {
  initialData?: Partial<HuntFormData>
  onSubmit: (data: HuntFormData) => Promise<void>
  onCancel?: () => void
  submitLabel?: string
}

export default function HuntForm({
  initialData,
  onSubmit,
  onCancel,
  submitLabel = 'Create Hunt'
}: HuntFormProps) {
  const [formData, setFormData] = useState<HuntFormData>({
    title: initialData?.title || '',
    description: initialData?.description || '',
    difficulty: initialData?.difficulty || 'easy',
    startTime: initialData?.startTime || '',
    durationMinutes: initialData?.durationMinutes || 30,
    maxParticipants: initialData?.maxParticipants,
    status: initialData?.status || 'upcoming',
    gameImageUrl: initialData?.gameImageUrl || '',
    prizes: initialData?.prizes || []
  })

  const [errors, setErrors] = useState<Partial<Record<keyof HuntFormData, string>>>({})
  const [loading, setLoading] = useState(false)

  const validate = (): boolean => {
    const newErrors: Partial<Record<keyof HuntFormData, string>> = {}

    if (!formData.title || formData.title.trim().length < 3) {
      newErrors.title = 'Title must be at least 3 characters'
    }

    if (!formData.description || formData.description.trim().length < 10) {
      newErrors.description = 'Description must be at least 10 characters'
    }

    if (!formData.startTime) {
      newErrors.startTime = 'Start time is required'
    }

    if (formData.durationMinutes < 5) {
      newErrors.durationMinutes = 'Duration must be at least 5 minutes'
    }

    if (formData.maxParticipants && formData.maxParticipants < 1) {
      newErrors.maxParticipants = 'Must be at least 1 participant'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validate()) {
      return
    }

    setLoading(true)
    try {
      await onSubmit(formData)
    } catch (error) {
      console.error('Form submission error:', error)
    } finally {
      setLoading(false)
    }
  }

  const calculateEndTime = () => {
    if (!formData.startTime || !formData.durationMinutes) return ''

    const start = new Date(formData.startTime)
    const end = new Date(start.getTime() + formData.durationMinutes * 60000)
    return end.toLocaleString()
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Input
        label="Hunt Title"
        value={formData.title}
        onChange={(e) => setFormData({ ...formData, title: e.target.value })}
        error={errors.title}
        placeholder="Enter hunt title"
        required
      />

      <Textarea
        label="Description"
        value={formData.description}
        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
        error={errors.description}
        placeholder="Describe the hunt..."
        rows={4}
        required
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Select
          label="Difficulty"
          value={formData.difficulty}
          onChange={(e) => setFormData({ ...formData, difficulty: e.target.value as any })}
          options={[
            { value: 'easy', label: 'Easy' },
            { value: 'medium', label: 'Medium' },
            { value: 'hard', label: 'Hard' }
          ]}
          required
        />

        <Select
          label="Status"
          value={formData.status}
          onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
          options={[
            { value: 'upcoming', label: 'Upcoming' },
            { value: 'active', label: 'Active' },
            { value: 'completed', label: 'Completed' }
          ]}
          required
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <DateTimeInput
          label="Start Date & Time"
          value={formData.startTime}
          onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
          error={errors.startTime}
          required
        />

        <Input
          type="number"
          label="Duration (minutes)"
          value={formData.durationMinutes}
          onChange={(e) => setFormData({ ...formData, durationMinutes: parseInt(e.target.value) })}
          error={errors.durationMinutes}
          min="5"
          step="5"
          required
        />
      </div>

      {formData.startTime && formData.durationMinutes > 0 && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-lg">
          <p className="text-sm text-emerald-800">
            <strong>Calculated End Time:</strong> {calculateEndTime()}
          </p>
        </div>
      )}

      <Input
        type="number"
        label="Max Participants (Optional)"
        value={formData.maxParticipants || ''}
        onChange={(e) => setFormData({ ...formData, maxParticipants: e.target.value ? parseInt(e.target.value) : undefined })}
        error={errors.maxParticipants}
        placeholder="Leave empty for unlimited"
        min="1"
      />

      {/* Game Image & Prizes Section */}
      <div className="border-t pt-6 space-y-6">
        <h3 className="text-lg font-semibold text-gray-900">Game Details</h3>

        {/* Game Image */}
        <ImageUpload
          label="Game Banner Image"
          value={formData.gameImageUrl}
          onChange={(url) => setFormData({ ...formData, gameImageUrl: url })}
          bucket="game-images"
          helperText="Upload a banner/thumbnail image for this game hunt"
        />

        {/* Prizes List */}
        <PrizesList
          prizes={formData.prizes || []}
          onChange={(prizes) => setFormData({ ...formData, prizes })}
        />
      </div>

      <div className="flex gap-4 pt-4">
        <Button type="submit" loading={loading} fullWidth>
          {submitLabel}
        </Button>
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel} fullWidth>
            Cancel
          </Button>
        )}
      </div>
    </form>
  )
}
