'use client'

import { useState } from 'react'
import Input from '../ui/Input'
import Textarea from '../ui/Textarea'
import Select from '../ui/Select'
import Button from '../ui/Button'

interface ClueFormData {
  orderNumber: number
  question: string
  hint?: string
  expectedAnswer: string
  answerType: 'text' | 'image' | 'both'
  validationType: 'exact' | 'keyword' | 'ai'
  points: number
}

interface ClueFormProps {
  huntId: string
  initialData?: Partial<ClueFormData>
  onSubmit: (data: ClueFormData) => Promise<void>
  onCancel?: () => void
  submitLabel?: string
  nextOrderNumber?: number
}

export default function ClueForm({
  huntId,
  initialData,
  onSubmit,
  onCancel,
  submitLabel = 'Add Clue',
  nextOrderNumber = 1
}: ClueFormProps) {
  const [formData, setFormData] = useState<ClueFormData>({
    orderNumber: initialData?.orderNumber || nextOrderNumber,
    question: initialData?.question || '',
    hint: initialData?.hint || '',
    expectedAnswer: initialData?.expectedAnswer || '',
    answerType: initialData?.answerType || 'image',
    validationType: initialData?.validationType || 'ai',
    points: initialData?.points || 10
  })

  const [errors, setErrors] = useState<Partial<Record<keyof ClueFormData, string>>>({})
  const [loading, setLoading] = useState(false)

  const validate = (): boolean => {
    const newErrors: Partial<Record<keyof ClueFormData, string>> = {}

    if (!formData.question || formData.question.trim().length < 10) {
      newErrors.question = 'Question must be at least 10 characters'
    }

    if (!formData.expectedAnswer || formData.expectedAnswer.trim().length === 0) {
      newErrors.expectedAnswer = 'Expected answer is required'
    }

    if (formData.points < 1 || formData.points > 10) {
      newErrors.points = 'Points must be between 1 and 10'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    console.log('ClueForm: handleSubmit called')
    console.log('ClueForm: formData =', formData)

    const isValid = validate()
    if (!isValid) {
      console.log('ClueForm: validation failed')
      alert('Please fix the validation errors before submitting')
      return
    }

    console.log('ClueForm: validation passed, submitting...')
    setLoading(true)
    try {
      await onSubmit(formData)
      console.log('ClueForm: submit successful')
    } catch (error) {
      console.error('ClueForm submission error:', error)
      alert('Error submitting clue: ' + (error instanceof Error ? error.message : 'Unknown error'))
    } finally {
      setLoading(false)
    }
  }

  const getValidationHelp = () => {
    switch (formData.validationType) {
      case 'exact':
        return 'Answer must match exactly (case-insensitive)'
      case 'keyword':
        return 'Answer must contain one of the keywords. Separate multiple keywords with commas.'
      case 'ai':
        return 'AI will evaluate if the answer is semantically correct using GPT-4'
      default:
        return ''
    }
  }

  const getAnswerTypeHelp = () => {
    switch (formData.answerType) {
      case 'text':
        return 'User will submit a text answer'
      case 'image':
        return 'User will upload an image that matches the criteria'
      case 'both':
        return 'User can submit either text or image answer'
      default:
        return ''
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Input
        type="number"
        label="Order Number"
        value={formData.orderNumber.toString()}
        onChange={(e) => setFormData({ ...formData, orderNumber: parseInt(e.target.value) || 1 })}
        error={errors.orderNumber}
        min="1"
        required
        helperText="Order in which this clue appears in the hunt"
      />

      <Textarea
        label="Question"
        value={formData.question}
        onChange={(e) => setFormData({ ...formData, question: e.target.value })}
        error={errors.question}
        placeholder="What is the question or clue for users to solve?"
        rows={4}
        required
      />

      <Textarea
        label="Hint (Optional)"
        value={formData.hint}
        onChange={(e) => setFormData({ ...formData, hint: e.target.value })}
        placeholder="Optional hint to help users if they get stuck"
        rows={2}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Select
          label="Answer Type"
          value={formData.answerType}
          onChange={(e) => setFormData({ ...formData, answerType: e.target.value as any })}
          options={[
            { value: 'text', label: 'Text Answer' },
            { value: 'image', label: 'Image Answer' },
            { value: 'both', label: 'Text or Image' }
          ]}
          helperText={getAnswerTypeHelp()}
          required
        />

        <Select
          label="Validation Type"
          value={formData.validationType}
          onChange={(e) => setFormData({ ...formData, validationType: e.target.value as any })}
          options={[
            { value: 'exact', label: 'Exact Match' },
            { value: 'keyword', label: 'Keyword Match' },
            { value: 'ai', label: 'AI Validation' }
          ]}
          helperText={getValidationHelp()}
          required
        />
      </div>

      <Textarea
        label="Expected Answer"
        value={formData.expectedAnswer}
        onChange={(e) => setFormData({ ...formData, expectedAnswer: e.target.value })}
        error={errors.expectedAnswer}
        placeholder={
          formData.validationType === 'keyword'
            ? 'red, blue, yellow'
            : formData.validationType === 'exact'
            ? 'Paris'
            : 'A detailed description of the expected answer for AI validation'
        }
        rows={3}
        required
        helperText={
          formData.validationType === 'keyword'
            ? 'For keyword validation, separate multiple acceptable answers with commas'
            : formData.validationType === 'ai'
            ? 'Provide a detailed description of what constitutes a correct answer'
            : 'The exact answer users must provide'
        }
      />

      <Input
        type="number"
        label="Points"
        value={formData.points}
        onChange={(e) => setFormData({ ...formData, points: parseInt(e.target.value) })}
        error={errors.points}
        min="1"
        max="10"
        step="1"
        required
        helperText="Points awarded for correctly answering this clue (1-10)"
      />

      {/* Information box about image validation */}
      {(formData.answerType === 'image' || formData.answerType === 'both') && (
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <h4 className="text-sm font-medium text-blue-900 mb-2">Image Answer Information</h4>
          <p className="text-sm text-blue-800">
            Images will be validated using:
          </p>
          <ul className="mt-2 text-sm text-blue-800 list-disc list-inside space-y-1">
            <li>AI generation detection (must be authentic photo)</li>
            <li>Web match detection (must be original, not downloaded)</li>
            <li>Object recognition (must contain expected objects/content)</li>
          </ul>
        </div>
      )}

      <div className="flex gap-4 pt-4">
        <Button type="submit" loading={loading} fullWidth>
          {submitLabel}
        </Button>
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel} fullWidth>
            Cancel
          </Button>
        )}
      </div>
    </form>
  )
}
