'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Table, { TableColumn } from '../ui/Table'
import Badge from '../ui/Badge'
import Input from '../ui/Input'
import Select from '../ui/Select'
import Pagination from '../ui/Pagination'
import Button from '../ui/Button'
import Modal from '../ui/Modal'

interface Hunt {
  id: string
  title: string
  description: string
  difficulty: 'easy' | 'medium' | 'hard'
  duration_minutes: number
  start_time: string
  end_time: string
  status: 'upcoming' | 'active' | 'completed'
  participant_count: number
  clue_count: number
  created_by_username: string
  created_at: string
}

interface GamesTableProps {
  hunts: Hunt[]
}

export default function GamesTable({ hunts }: GamesTableProps) {
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState<'all' | 'upcoming' | 'active' | 'completed'>('all')
  const [currentPage, setCurrentPage] = useState(1)
  const [deleteHuntId, setDeleteHuntId] = useState<string | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)

  const itemsPerPage = 20

  // Filter hunts
  const filteredHunts = hunts.filter((hunt) => {
    const matchesSearch = hunt.title.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || hunt.status === statusFilter
    return matchesSearch && matchesStatus
  })

  // Paginate
  const totalPages = Math.ceil(filteredHunts.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const paginatedHunts = filteredHunts.slice(startIndex, startIndex + itemsPerPage)

  const handleDelete = async () => {
    if (!deleteHuntId) return

    setIsDeleting(true)
    try {
      const response = await fetch(`/api/admin/hunts/${deleteHuntId}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        setDeleteHuntId(null)
        router.refresh()
      } else {
        alert('Failed to delete hunt')
      }
    } catch (error) {
      console.error('Error deleting hunt:', error)
      alert('An error occurred')
    } finally {
      setIsDeleting(false)
    }
  }

  const columns: TableColumn[] = [
    {
      key: 'title',
      label: 'Title',
      sortable: true,
      render: (value: string, row: Hunt) => (
        <div>
          <div className="font-medium">{value}</div>
          <div className="text-xs text-gray-500">
            {row.difficulty.charAt(0).toUpperCase() + row.difficulty.slice(1)} • {row.duration_minutes} min
          </div>
        </div>
      )
    },
    {
      key: 'status',
      label: 'Status',
      sortable: true,
      render: (value: string) => (
        <Badge
          variant={
            value === 'active' ? 'success' :
            value === 'upcoming' ? 'info' :
            'default'
          }
        >
          {value.toUpperCase()}
        </Badge>
      )
    },
    {
      key: 'start_time',
      label: 'Start Time',
      sortable: true,
      render: (value: string) => new Date(value).toLocaleString()
    },
    {
      key: 'participant_count',
      label: 'Participants',
      sortable: true
    },
    {
      key: 'clue_count',
      label: 'Clues',
      sortable: true
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (_: any, row: Hunt) => (
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => router.push(`/admin/games/${row.id}`)}
          >
            View
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => router.push(`/admin/games/${row.id}/edit`)}
          >
            Edit
          </Button>
          <Button
            variant="danger"
            size="sm"
            onClick={() => setDeleteHuntId(row.id)}
          >
            Delete
          </Button>
        </div>
      )
    }
  ]

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="bg-white p-4 rounded-lg shadow-md border border-gray-200">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-2">
            <Input
              placeholder="Search by title..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value)
                setCurrentPage(1)
              }}
            />
          </div>
          <Select
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value as any)
              setCurrentPage(1)
            }}
            options={[
              { value: 'all', label: 'All Statuses' },
              { value: 'upcoming', label: 'Upcoming' },
              { value: 'active', label: 'Active' },
              { value: 'completed', label: 'Completed' }
            ]}
          />
        </div>
      </div>

      {/* Stats */}
      <div className="flex items-center justify-between text-sm text-gray-600">
        <p>
          Showing {startIndex + 1}-{Math.min(startIndex + itemsPerPage, filteredHunts.length)} of{' '}
          {filteredHunts.length} hunts
        </p>
        <p>
          Total: {hunts.length} hunts ({hunts.filter(h => h.status === 'active').length} active)
        </p>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg shadow-md border border-gray-200 overflow-hidden">
        <Table
          columns={columns}
          data={paginatedHunts}
          emptyMessage="No hunts found"
        />
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={setCurrentPage}
        />
      )}

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={!!deleteHuntId}
        onClose={() => setDeleteHuntId(null)}
        title="Delete Hunt"
      >
        <div className="space-y-4">
          <p className="text-gray-700">
            Are you sure you want to delete this hunt? This action cannot be undone.
          </p>
          <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-sm text-red-800">
              <strong>Warning:</strong> All clues, participants, and submissions associated with this hunt will also be deleted.
            </p>
          </div>
          <div className="flex gap-3">
            <Button
              variant="danger"
              onClick={handleDelete}
              loading={isDeleting}
              fullWidth
            >
              Delete Hunt
            </Button>
            <Button
              variant="outline"
              onClick={() => setDeleteHuntId(null)}
              fullWidth
            >
              Cancel
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}
