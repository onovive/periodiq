'use client'

import { useState } from 'react'
import Table, { TableColumn } from '../ui/Table'
import Badge from '../ui/Badge'
import Input from '../ui/Input'
import Select from '../ui/Select'
import Pagination from '../ui/Pagination'
import Button from '../ui/Button'
import Modal from '../ui/Modal'
import { useRouter } from 'next/navigation'

interface User {
  id: string
  username: string
  role: 'user' | 'admin'
  avatar_url?: string
  created_at: string
  updated_at: string
}

interface UsersTableProps {
  users: User[]
}

export default function UsersTable({ users }: UsersTableProps) {
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState('')
  const [roleFilter, setRoleFilter] = useState<'all' | 'user' | 'admin'>('all')
  const [currentPage, setCurrentPage] = useState(1)
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [isRoleModalOpen, setIsRoleModalOpen] = useState(false)
  const [newRole, setNewRole] = useState<'user' | 'admin'>('user')
  const [isUpdating, setIsUpdating] = useState(false)

  const itemsPerPage = 20

  // Filter users
  const filteredUsers = users.filter((user) => {
    const matchesSearch = user.username.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesRole = roleFilter === 'all' || user.role === roleFilter
    return matchesSearch && matchesRole
  })

  // Paginate
  const totalPages = Math.ceil(filteredUsers.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const paginatedUsers = filteredUsers.slice(startIndex, startIndex + itemsPerPage)

  const handleRoleChange = async () => {
    if (!selectedUser) return

    setIsUpdating(true)
    try {
      const response = await fetch(`/api/admin/users/${selectedUser.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: newRole })
      })

      if (response.ok) {
        setIsRoleModalOpen(false)
        setSelectedUser(null)
        router.refresh()
      } else {
        alert('Failed to update user role')
      }
    } catch (error) {
      console.error('Error updating role:', error)
      alert('An error occurred')
    } finally {
      setIsUpdating(false)
    }
  }

  const openRoleModal = (user: User) => {
    setSelectedUser(user)
    setNewRole(user.role)
    setIsRoleModalOpen(true)
  }

  const columns: TableColumn[] = [
    {
      key: 'username',
      label: 'Username',
      sortable: true,
      render: (value: string) => (
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center">
            <span className="text-emerald-600 font-medium text-sm">
              {value.charAt(0).toUpperCase()}
            </span>
          </div>
          <span className="font-medium">{value}</span>
        </div>
      )
    },
    {
      key: 'role',
      label: 'Role',
      sortable: true,
      render: (value: string) => (
        <Badge variant={value === 'admin' ? 'admin' : 'default'}>
          {value.toUpperCase()}
        </Badge>
      )
    },
    {
      key: 'created_at',
      label: 'Joined',
      sortable: true,
      render: (value: string) => new Date(value).toLocaleDateString()
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (_: any, row: User) => (
        <Button
          variant="outline"
          size="sm"
          onClick={() => openRoleModal(row)}
        >
          Change Role
        </Button>
      )
    }
  ]

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="bg-white p-4 rounded-lg shadow-md border border-gray-200">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-2">
            <Input
              placeholder="Search by username..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value)
                setCurrentPage(1)
              }}
            />
          </div>
          <Select
            value={roleFilter}
            onChange={(e) => {
              setRoleFilter(e.target.value as any)
              setCurrentPage(1)
            }}
            options={[
              { value: 'all', label: 'All Roles' },
              { value: 'user', label: 'Users Only' },
              { value: 'admin', label: 'Admins Only' }
            ]}
          />
        </div>
      </div>

      {/* Stats */}
      <div className="flex items-center justify-between text-sm text-gray-600">
        <p>
          Showing {startIndex + 1}-{Math.min(startIndex + itemsPerPage, filteredUsers.length)} of{' '}
          {filteredUsers.length} users
        </p>
        <p>
          Total: {users.length} users ({users.filter(u => u.role === 'admin').length} admins)
        </p>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg shadow-md border border-gray-200 overflow-hidden">
        <Table
          columns={columns}
          data={paginatedUsers}
          emptyMessage="No users found"
        />
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={setCurrentPage}
        />
      )}

      {/* Role Change Modal */}
      {selectedUser && (
        <Modal
          isOpen={isRoleModalOpen}
          onClose={() => {
            setIsRoleModalOpen(false)
            setSelectedUser(null)
          }}
          title="Change User Role"
        >
          <div className="space-y-4">
            <p className="text-gray-700">
              Change role for <strong>{selectedUser.username}</strong>
            </p>

            <Select
              label="New Role"
              value={newRole}
              onChange={(e) => setNewRole(e.target.value as any)}
              options={[
                { value: 'user', label: 'User' },
                { value: 'admin', label: 'Admin' }
              ]}
            />

            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-sm text-yellow-800">
                <strong>Warning:</strong> Admins have full access to all platform features including user management, hunt creation, and system settings.
              </p>
            </div>

            <div className="flex gap-3">
              <Button
                onClick={handleRoleChange}
                loading={isUpdating}
                fullWidth
              >
                Update Role
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setIsRoleModalOpen(false)
                  setSelectedUser(null)
                }}
                fullWidth
              >
                Cancel
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  )
}
