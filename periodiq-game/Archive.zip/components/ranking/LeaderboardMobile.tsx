'use client';

interface LeaderboardMobileProps {
  rankings: Array<{
    rank: number;
    user_id: string;
    total_clues_solved: number;
    total_clues: number;
    completion_time: string | null;
    profiles: {
      username: string;
      avatar_url: string | null;
    };
  }>;
  currentUserId: string;
  huntTitle: string;
}

export default function LeaderboardMobile({ rankings, currentUserId, huntTitle }: LeaderboardMobileProps) {
  const formatTime = (timeString: string | null) => {
    if (!timeString) return 'He gave up';

    const match = timeString.match(/(\d{2}):(\d{2}):(\d{2})/);
    if (match) {
      return `${match[1]}:${match[2]}:${match[3]}`;
    }
    return timeString;
  };

  const getRankDisplay = (rank: number) => {
    if (rank === 1) return '1';
    if (rank === 2) return '2';
    if (rank === 3) return '3';
    return rank.toString();
  };

  const getRankColor = (rank: number) => {
    if (rank === 1) return 'text-yellow-600';
    if (rank === 2) return 'text-gray-500';
    if (rank === 3) return 'text-orange-600';
    return 'text-gray-700';
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-4">
        <div className="flex items-center">
          <button className="p-2 -ml-2">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h1 className="flex-1 text-center font-semibold text-gray-900">Final Standings</h1>
          <div className="w-6" /> {/* Spacer */}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 py-6">
        {/* Title */}
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">FINAL RANKING</h2>
          <div className="text-sm text-gray-600">{huntTitle}</div>
        </div>

        {/* Success Message */}
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
          <div className="text-green-800 text-sm text-center">
            Here's the final ranking! Winners will be contacted about their prizes.
          </div>
        </div>

        {/* Total Participants */}
        <div className="bg-gray-100 rounded-lg p-3 mb-4 text-center">
          <div className="font-semibold text-gray-700">TOTAL PARTICIPANTS: {rankings.length}</div>
        </div>

        {/* Table Header */}
        <div className="grid grid-cols-12 gap-2 px-3 py-2 text-xs font-semibold text-gray-600 border-b border-gray-200">
          <div className="col-span-1">POS.</div>
          <div className="col-span-5">PLAYER</div>
          <div className="col-span-3 text-center">CLUES</div>
          <div className="col-span-3 text-right">TIME</div>
        </div>

        {/* Rankings List */}
        <div className="divide-y divide-gray-200">
          {rankings.map((ranking) => {
            const isCurrentUser = ranking.user_id === currentUserId;
            const displayName = ranking.profiles?.username || 'User...';
            const truncatedName = displayName.length > 12 ? displayName.substring(0, 9) + '...' : displayName;

            return (
              <div
                key={ranking.user_id}
                className={`grid grid-cols-12 gap-2 px-3 py-3 items-center ${
                  isCurrentUser ? 'bg-blue-50' : ''
                } ${ranking.rank <= 3 ? 'bg-yellow-50' : ''}`}
              >
                {/* Rank */}
                <div className={`col-span-1 font-bold text-lg ${getRankColor(ranking.rank)}`}>
                  {getRankDisplay(ranking.rank)}
                </div>

                {/* Player */}
                <div className="col-span-5 flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-gray-300 flex-shrink-0 overflow-hidden">
                    {ranking.profiles?.avatar_url ? (
                      <img
                        src={ranking.profiles.avatar_url}
                        alt={truncatedName}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-blue-400 to-blue-600" />
                    )}
                  </div>
                  <span className="text-sm font-medium text-gray-900 truncate">{truncatedName}</span>
                </div>

                {/* Clues */}
                <div className="col-span-3 text-center">
                  <span className="text-sm font-semibold text-gray-900">
                    {ranking.total_clues_solved} / {ranking.total_clues}
                  </span>
                </div>

                {/* Time */}
                <div className="col-span-3 text-right">
                  <div className="text-sm font-medium text-gray-900">
                    {formatTime(ranking.completion_time)}
                  </div>
                  {ranking.rank > 3 && ranking.completion_time && (
                    <div className="text-xs text-gray-500 italic">He gave up</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Fixed Bottom Button */}
      <div className="border-t border-gray-200 px-4 py-4 bg-white">
        <button className="w-full bg-gray-100 text-gray-700 font-semibold py-3 rounded-lg">
          Return to Dashboard
        </button>
      </div>
    </div>
  );
}
