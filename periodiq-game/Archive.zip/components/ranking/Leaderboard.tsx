import Card from '@/components/ui/Card';
import { Database } from '@/lib/types/database';

type Ranking = Database['public']['Tables']['rankings']['Row'] & {
  profiles: {
    username: string;
    avatar_url: string | null;
  } | null;
};

interface LeaderboardProps {
  rankings: Ranking[];
  currentUserId?: string;
}

export default function Leaderboard({ rankings, currentUserId }: LeaderboardProps) {
  const formatDuration = (interval: string) => {
    // Parse PostgreSQL interval format (e.g., "00:45:30")
    const parts = interval.split(':');
    if (parts.length === 3) {
      const hours = parseInt(parts[0]);
      const minutes = parseInt(parts[1]);
      const seconds = parseInt(parts[2]);

      if (hours > 0) {
        return `${hours}h ${minutes}m ${seconds}s`;
      }
      return `${minutes}m ${seconds}s`;
    }
    return interval;
  };

  const getMedalIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return (
          <span className="text-3xl">🥇</span>
        );
      case 2:
        return (
          <span className="text-3xl">🥈</span>
        );
      case 3:
        return (
          <span className="text-3xl">🥉</span>
        );
      default:
        return (
          <span className="text-xl font-bold text-gray-500">#{rank}</span>
        );
    }
  };

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-r from-yellow-50 to-yellow-100 border-yellow-300';
      case 2:
        return 'bg-gradient-to-r from-gray-50 to-gray-100 border-gray-300';
      case 3:
        return 'bg-gradient-to-r from-orange-50 to-orange-100 border-orange-300';
      default:
        return 'bg-white border-gray-200';
    }
  };

  if (rankings.length === 0) {
    return (
      <div className="text-center py-12 bg-white rounded-xl">
        <svg className="w-16 h-16 mx-auto text-gray-300 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
        </svg>
        <h3 className="text-xl font-semibold text-gray-900 mb-2">No Rankings Yet</h3>
        <p className="text-gray-600">Rankings will be calculated 24 hours after the hunt ends</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {rankings.map((ranking) => {
        const isCurrentUser = ranking.user_id === currentUserId;
        return (
          <div
            key={ranking.id}
            className={`
              border-2 rounded-xl transition-all
              ${getRankColor(ranking.rank)}
              ${isCurrentUser ? 'ring-4 ring-emerald-500 ring-opacity-50' : ''}
            `}
          >
            <div className="p-4 flex items-center">
              <div className="flex-shrink-0 w-16 flex items-center justify-center">
                {getMedalIcon(ranking.rank)}
              </div>

              <div className="flex-1 ml-4">
                <div className="flex items-center">
                  <h3 className={`text-lg font-bold ${isCurrentUser ? 'text-emerald-700' : 'text-gray-900'}`}>
                    {ranking.profiles?.username || 'Anonymous'}
                  </h3>
                  {isCurrentUser && (
                    <span className="ml-2 px-2 py-0.5 bg-emerald-100 text-emerald-700 text-xs font-semibold rounded-full">
                      You
                    </span>
                  )}
                </div>
                <div className="flex items-center mt-1 text-sm text-gray-600">
                  <svg className="w-4 h-4 mr-1 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  {formatDuration(ranking.completion_time)}
                </div>
              </div>

              <div className="text-right">
                <div className="text-2xl font-bold text-emerald-600">
                  {ranking.total_score}
                </div>
                <div className="text-xs text-gray-500">points</div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
