'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import AvatarUpload from '@/components/ui/AvatarUpload';

const EXPLORER_TYPES = [
  { value: 'urban_explorer', label: 'URBAN EXPLORER', color: 'bg-emerald-600' },
  { value: 'trailblazer', label: 'TRAILBLAZER', color: 'bg-blue-500' },
  { value: 'mystery_hunter', label: 'MYSTERY HUNTER', color: 'bg-orange-500' },
  { value: 'geo_spy', label: 'GEO SPY', color: 'bg-purple-600' },
  { value: 'riddle_solver', label: 'RIDDLE SOLVER', color: 'bg-red-500' },
  { value: 'digital_detective', label: 'DIGITAL DETECTIVE', color: 'bg-cyan-500' },
];

interface OnboardingFormProps {
  userId: string;
}

export default function OnboardingForm({ userId }: OnboardingFormProps) {
  const router = useRouter();
  const [name, setName] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [selectedExplorerType, setSelectedExplorerType] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const isFormValid = name.trim().length >= 3 && avatarUrl !== '' && selectedExplorerType !== '';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!isFormValid) {
      setError('Please fill in all required fields');
      return;
    }

    setError('');
    setLoading(true);

    try {
      const supabase = createClient();

      // @ts-expect-error - Supabase type inference issue with profiles table
      const { error: updateError } = await supabase.from('profiles').update({
        display_name: name.trim(),
        avatar: avatarUrl,
        explorer_type: selectedExplorerType,
        onboarding_completed: true,
      }).eq('id', userId);

      if (updateError) throw updateError;

      router.push('/dashboard');
      router.refresh();
    } catch (err: any) {
      setError(err.message || 'Failed to save profile');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
          {error}
        </div>
      )}

      {/* Avatar Upload */}
      <div>
        <label className="block text-lg font-semibold text-gray-900 mb-4 text-center">
          Info Utente (Richiesto):
        </label>
        <AvatarUpload
          value={avatarUrl}
          onChange={setAvatarUrl}
        />
      </div>

      {/* Name Input */}
      <div>
        <Input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Scegli il tuo nome utente"
          required
          minLength={3}
        />
      </div>

      {/* Explorer Type Selection */}
      <div>
        <label className="block text-lg font-semibold text-gray-900 mb-4 text-center">
          Seleziona il tuo Explorer Type (Richiesto):
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {EXPLORER_TYPES.map((type) => (
            <button
              key={type.value}
              type="button"
              onClick={() => setSelectedExplorerType(type.value)}
              className={`px-4 py-3 rounded-xl font-bold text-white text-sm transition-all transform hover:scale-105 hover:shadow-lg ${
                selectedExplorerType === type.value
                  ? type.color + ' shadow-xl scale-105 ring-4 ring-white'
                  : type.color
              }`}
            >
              {type.label}
            </button>
          ))}
        </div>
      </div>

      <Button
        type="submit"
        fullWidth
        size="lg"
        loading={loading}
        disabled={!isFormValid}
      >
        CONTINUE
      </Button>
    </form>
  );
}
