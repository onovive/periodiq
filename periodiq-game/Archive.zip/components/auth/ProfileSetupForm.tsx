'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';

export default function ProfileSetupForm() {
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (username.length < 3) {
      setError('Username must be at least 3 characters');
      return;
    }

    setLoading(true);

    try {
      const supabase = createClient();

      console.log('Getting user...');
      const { data: { user }, error: userError } = await supabase.auth.getUser();

      if (userError) {
        console.error('User error:', userError);
        throw userError;
      }

      if (!user) {
        console.error('No user found');
        throw new Error('No user found');
      }

      console.log('User found:', user.id);
      console.log('Updating profile with username:', username);

      // First check if profile exists
      const { data: existingProfile, error: fetchError } = await supabase
        .from('profiles')
        .select('id')
        .eq('id', user.id)
        .single();

      console.log('Existing profile check:', { existingProfile, fetchError });

      let updateError;
      let data;

      if (!existingProfile && fetchError?.code === 'PGRST116') {
        // Profile doesn't exist, create it
        console.log('Profile does not exist, creating new profile...');
        const result = await supabase
          .from('profiles')
          // @ts-expect-error - Supabase type inference issue
          .insert({ id: user.id, username })
          .select();

        data = result.data;
        updateError = result.error;
        console.log('Insert response:', { data, error: updateError });
      } else {
        // Profile exists, update it
        console.log('Profile exists, updating...');
        const result = await supabase
          .from('profiles')
          // @ts-expect-error - Supabase type inference issue
          .update({ username })
          .eq('id', user.id)
          .select();

        data = result.data;
        updateError = result.error;
        console.log('Update response:', { data, error: updateError });
      }

      if (updateError) {
        console.error('Operation error:', updateError);
        throw updateError;
      }

      console.log('Profile updated successfully, navigating to dashboard...');

      // Small delay to ensure database propagation
      await new Promise(resolve => setTimeout(resolve, 100));

      // Refresh router data before navigating
      router.refresh();

      // Navigate to dashboard
      router.push('/dashboard');
    } catch (err: any) {
      console.error('Full error:', err);
      if (err.code === '23505') {
        setError('Username already taken');
      } else {
        setError(err.message || 'Failed to update profile');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
          {error}
        </div>
      )}

      <Input
        label="Username"
        type="text"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        placeholder="Choose a username"
        helperText="This will be your display name in hunts"
        required
      />

      <Button type="submit" fullWidth loading={loading}>
        Complete Setup
      </Button>
    </form>
  );
}
