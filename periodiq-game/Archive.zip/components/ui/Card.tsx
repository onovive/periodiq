import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  padding?: 'none' | 'sm' | 'md' | 'lg' | 'xl';
  hover?: boolean;
  variant?: 'default' | 'bordered' | 'elevated';
}

export default function Card({
  children,
  className = '',
  padding = 'md',
  hover = false,
  variant = 'default'
}: CardProps) {
  const paddingClasses = {
    none: '',
    sm: 'p-4',
    md: 'p-6',
    lg: 'p-8',
    xl: 'p-10'
  };

  const variantClasses = {
    default: 'bg-white shadow-card border border-gray-100',
    bordered: 'bg-white border-2 border-gray-200',
    elevated: 'bg-white shadow-lg border border-gray-100'
  };

  const hoverClass = hover ? 'hover:shadow-card-hover hover:-translate-y-0.5 transition-all duration-300 cursor-pointer' : '';

  return (
    <div className={`rounded-xl ${variantClasses[variant]} ${paddingClasses[padding]} ${hoverClass} ${className}`}>
      {children}
    </div>
  );
}
