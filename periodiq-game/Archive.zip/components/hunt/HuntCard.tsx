import Link from 'next/link';
import { Database } from '@/lib/types/database';

type Hunt = Database['public']['Tables']['hunts']['Row'];

interface HuntCardProps {
  hunt: Hunt & { participant_count?: number; user_subscribed?: boolean };
}

export default function HuntCard({ hunt }: HuntCardProps) {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'upcoming':
        return <span className="inline-block px-2 py-0.5 bg-blue-100 text-blue-700 text-xs font-medium rounded">UPCOMING</span>;
      case 'active':
        return <span className="inline-block px-2 py-0.5 bg-green-100 text-green-700 text-xs font-medium rounded">ACTIVE</span>;
      case 'completed':
        return <span className="inline-block px-2 py-0.5 bg-gray-100 text-gray-700 text-xs font-medium rounded">ENDED</span>;
      default:
        return null;
    }
  };

  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);
    const day = date.getDate();
    const month = date.toLocaleString('en-US', { month: 'short' }).toUpperCase();
    const time = date.toLocaleString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
    return { day, month, time };
  };

  const startDate = formatDateTime(hunt.start_time);

  return (
    <Link href={`/hunts/${hunt.id}`} className="block group">
      <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden hover:shadow-xl hover:border-emerald-300 hover:-translate-y-0.5 transition-all duration-300">
        <div className="flex gap-5 p-6">
          {/* Hunt Image */}
          <div className="w-28 h-28 flex-shrink-0 rounded-xl overflow-hidden bg-gray-100 shadow-md ring-2 ring-gray-100 group-hover:ring-emerald-200 transition-all duration-300">
            {hunt.game_image_url ? (
              <img
                src={hunt.game_image_url}
                alt={hunt.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center">
                <svg className="w-14 h-14 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            )}
          </div>

          {/* Hunt Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-3 mb-3">
              <h3 className="font-bold text-gray-900 text-lg line-clamp-2 leading-snug group-hover:text-emerald-700 transition-colors">
                {hunt.title}
              </h3>
              {getStatusBadge(hunt.status)}
            </div>

            <div className="flex items-center gap-2.5 text-sm text-gray-700 font-medium mb-3">
              <svg className="w-4.5 h-4.5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              <span>Inizio: {startDate.day} {startDate.month}, {startDate.time}</span>
            </div>

            <div className="flex items-center gap-2.5 text-sm text-gray-600 mb-4">
              <svg className="w-4.5 h-4.5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
              </svg>
              <span>Indizi: <span className="font-semibold text-gray-900">{hunt.duration_minutes || 10}</span></span>
            </div>

            {/* Prize Icons */}
            <div className="flex gap-2.5">
              <div className="flex items-center gap-1.5 bg-linear-to-r from-yellow-50 to-yellow-100 border border-yellow-300 rounded-lg px-3 py-1.5 shadow-sm">
                <span className="text-base font-bold">🏆</span>
                <span className="text-xs font-semibold text-yellow-800">1st</span>
              </div>
              <div className="flex items-center gap-1.5 bg-linear-to-r from-gray-50 to-gray-100 border border-gray-300 rounded-lg px-3 py-1.5 shadow-sm">
                <span className="text-base font-bold">🥈</span>
                <span className="text-xs font-semibold text-gray-700">2nd</span>
              </div>
              <div className="flex items-center gap-1.5 bg-linear-to-r from-orange-50 to-orange-100 border border-orange-300 rounded-lg px-3 py-1.5 shadow-sm">
                <span className="text-base font-bold">🥉</span>
                <span className="text-xs font-semibold text-orange-700">3rd</span>
              </div>
            </div>
          </div>
        </div>

        {/* Participants Strip */}
        <div className="bg-linear-to-r from-gray-50 to-gray-100 px-6 py-3.5 flex items-center justify-between border-t border-gray-200">
          <div className="flex items-center gap-2.5">
            <svg className="w-5 h-5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
            </svg>
            <span className="text-sm text-gray-700">
              Partecipanti: <span className="font-semibold text-gray-900">{hunt.participant_count || 0}</span>
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
}
