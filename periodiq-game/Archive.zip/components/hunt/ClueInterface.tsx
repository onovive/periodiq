'use client';

import { useState, useRef, useEffect } from 'react';
import Card from '@/components/ui/Card';
import Input from '@/components/ui/Input';
import Button from '@/components/ui/Button';
import Modal from '@/components/ui/Modal';
import { Database } from '@/lib/types/database';

type Clue = Database['public']['Tables']['clues']['Row'];
type Submission = Database['public']['Tables']['submissions']['Row'];

interface ValidationResult {
  success: boolean;
  feedback?: string;
  isCorrect?: boolean;
  pointsEarned?: number;
  aiGenerated?: boolean;
  foundOnWeb?: boolean;
  matchesAnswer?: boolean;
}

interface ClueInterfaceProps {
  clue: Clue;
  clueNumber: number;
  totalClues: number;
  participantId: string;
  previousSubmission?: Submission | null;
  onSubmit: (answer: string, imageFile?: File) => Promise<ValidationResult>;
}

export default function ClueInterface({
  clue,
  clueNumber,
  totalClues,
  participantId,
  previousSubmission,
  onSubmit,
}: ClueInterfaceProps) {
  const [answer, setAnswer] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [feedback, setFeedback] = useState<{
    message: string;
    isCorrect: boolean;
    points: number;
    aiGenerated?: boolean;
    foundOnWeb?: boolean;
    matchesAnswer?: boolean;
  } | null>(null);
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const alreadyAnswered = !!previousSubmission;
  const isImageAnswer = clue.answer_type === 'image' || clue.answer_type === 'both';

  // Detect if user is on mobile device
  useEffect(() => {
    const checkMobile = () => {
      const userAgent = navigator.userAgent.toLowerCase();
      const isMobileDevice = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(userAgent);
      const hasTouchScreen = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
      setIsMobile(isMobileDevice || hasTouchScreen);
    };
    checkMobile();
  }, []);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted', { answer, imageFile, alreadyAnswered, isImageAnswer });

    if (alreadyAnswered) return;

    // For image answers, require image file
    if (isImageAnswer && !imageFile) {
      alert('Please take a photo');
      return;
    }

    setLoading(true);
    console.log('Submitting answer...');
    try {
      const result = await onSubmit(answer.trim() || 'image-answer', imageFile || undefined);
      console.log('Submit result:', result);

      if (result.success) {
        setFeedback({
          message: result.feedback || (result.isCorrect ? 'Correct!' : 'Incorrect answer'),
          isCorrect: result.isCorrect || false,
          points: result.pointsEarned || 0,
          aiGenerated: result.aiGenerated,
          foundOnWeb: result.foundOnWeb,
          matchesAnswer: result.matchesAnswer,
        });
        setShowFeedbackModal(true);
        setAnswer('');
        setImageFile(null);
        setImagePreview('');
      }
    } catch (error) {
      console.error('Error submitting answer:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Card padding="lg" className="mb-8 shadow-lg">
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-bold text-emerald-700 bg-emerald-100 px-3 py-1.5 rounded-full">
              Clue {clueNumber} of {totalClues}
            </span>
            <span className="text-sm font-bold text-gray-700 bg-gray-100 px-3 py-1.5 rounded-full">
              {clue.points} points
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5 shadow-inner">
            <div
              className="bg-linear-to-r from-emerald-500 to-emerald-600 h-2.5 rounded-full transition-all shadow-sm"
              style={{ width: `${(clueNumber / totalClues) * 100}%` }}
            />
          </div>
        </div>

        <h2 className="text-3xl font-bold text-gray-900 mb-6 leading-tight">
          {clue.question}
        </h2>

        {clue.hint && (
          <div className="mb-6">
            <button
              onClick={() => setShowHint(!showHint)}
              className="text-emerald-600 hover:text-emerald-700 font-semibold flex items-center gap-2 transition-colors"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
              </svg>
              {showHint ? 'Hide Hint' : 'Show Hint'}
            </button>
            {showHint && (
              <div className="mt-3 p-4 bg-linear-to-br from-yellow-50 to-yellow-100 border-l-4 border-yellow-400 rounded-lg text-yellow-900 shadow-sm">
                <p className="font-medium">{clue.hint}</p>
              </div>
            )}
          </div>
        )}

        {alreadyAnswered ? (
          <div className={`p-6 rounded-xl shadow-md ${
            previousSubmission.is_correct
              ? 'bg-linear-to-br from-emerald-50 to-emerald-100 border-2 border-emerald-300'
              : 'bg-linear-to-br from-red-50 to-red-100 border-2 border-red-300'
          }`}>
            <div className="flex items-center gap-3 mb-4">
              {previousSubmission.is_correct ? (
                <svg className="w-8 h-8 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              ) : (
                <svg className="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              )}
              <span className={`text-xl font-bold ${
                previousSubmission.is_correct ? 'text-emerald-800' : 'text-red-800'
              }`}>
                {previousSubmission.is_correct ? 'Correct!' : 'Incorrect'}
              </span>
            </div>
            {previousSubmission.image_url && (
              <img
                src={previousSubmission.image_url}
                alt="Your submission"
                className="w-full max-w-md rounded-xl mb-4 shadow-md"
              />
            )}
            {!isImageAnswer && <p className="text-gray-800 font-medium mb-3">Your answer: {previousSubmission.answer}</p>}
            {previousSubmission.ai_feedback && (
              <p className="text-gray-700 mt-3 text-sm bg-white bg-opacity-60 p-3 rounded-lg">{previousSubmission.ai_feedback}</p>
            )}
            <p className="text-gray-800 mt-4 font-bold text-lg">
              Points earned: {previousSubmission.points_earned}
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            {isImageAnswer ? (
              <div className="space-y-4">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handleImageSelect}
                  className="hidden"
                />

                {imagePreview ? (
                  <div className="space-y-4">
                    <img
                      src={imagePreview}
                      alt="Preview"
                      className="w-full rounded-xl border-2 border-gray-300 shadow-lg"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      fullWidth
                      onClick={() => fileInputRef.current?.click()}
                      className="font-semibold"
                    >
                      Change Photo
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {isMobile ? (
                      <>
                        <Button
                          type="button"
                          fullWidth
                          onClick={() => fileInputRef.current?.click()}
                          className="bg-linear-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-md py-4"
                        >
                          <svg className="w-6 h-6 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                          </svg>
                          Take Photo
                        </Button>
                        <p className="text-sm text-gray-600 text-center font-medium">
                          Take a photo that matches the clue description
                        </p>
                      </>
                    ) : (
                      <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-300 rounded-xl p-8 text-center">
                        <svg className="w-16 h-16 text-blue-600 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
                        </svg>
                        <h3 className="text-2xl font-bold text-gray-900 mb-3">Use Your Phone to Play</h3>
                        <p className="text-gray-700 text-lg leading-relaxed">
                          This hunt requires taking photos with your camera. Please open this game on your mobile phone to participate.
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ) : (
              <Input
                label="Your Answer"
                value={answer}
                onChange={(e) => setAnswer(e.target.value)}
                placeholder="Enter your answer..."
                disabled={loading || alreadyAnswered}
              />
            )}

            <Button
              type="submit"
              fullWidth
              loading={loading}
              disabled={(isImageAnswer && !imageFile) || (!isImageAnswer && !answer.trim()) || alreadyAnswered}
              className="mt-6 font-bold text-lg py-4 shadow-lg"
            >
              {loading ? 'Validating...' : 'Submit Answer'}
            </Button>
          </form>
        )}
      </Card>

      <Modal
        isOpen={showFeedbackModal}
        onClose={() => setShowFeedbackModal(false)}
        title="Answer Feedback"
      >
        {feedback && (
          <div className="text-center">
            {feedback.isCorrect ? (
              <div className="mb-6">
                <svg className="w-20 h-20 text-emerald-500 mx-auto drop-shadow-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h3 className="text-3xl font-bold text-emerald-700 mt-5">Correct!</h3>
              </div>
            ) : (
              <div className="mb-6">
                <svg className="w-20 h-20 text-red-500 mx-auto drop-shadow-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h3 className="text-3xl font-bold text-red-700 mt-5">Incorrect</h3>
              </div>
            )}

            <p className="text-gray-700 mb-6 text-lg">{feedback.message}</p>

            {/* Show detailed validation results for image submissions */}
            {(feedback.aiGenerated !== undefined || feedback.foundOnWeb !== undefined || feedback.matchesAnswer !== undefined) && (
              <div className="bg-gray-50 rounded-xl p-5 mb-6 text-left shadow-inner">
                <h4 className="font-bold text-gray-900 mb-4 text-center text-lg">Validation Details</h4>
                <div className="space-y-3">
                  {feedback.aiGenerated !== undefined && (
                    <div className="flex items-center justify-between p-3 bg-white rounded-lg">
                      <span className="text-sm font-medium text-gray-700">AI Generated Check:</span>
                      <span className={`font-bold text-sm ${feedback.aiGenerated ? 'text-red-600' : 'text-emerald-600'}`}>
                        {feedback.aiGenerated ? '✗ Detected' : '✓ Passed'}
                      </span>
                    </div>
                  )}
                  {feedback.foundOnWeb !== undefined && (
                    <div className="flex items-center justify-between p-3 bg-white rounded-lg">
                      <span className="text-sm font-medium text-gray-700">Web Image Check:</span>
                      <span className={`font-bold text-sm ${feedback.foundOnWeb ? 'text-red-600' : 'text-emerald-600'}`}>
                        {feedback.foundOnWeb ? '✗ Found Online' : '✓ Passed'}
                      </span>
                    </div>
                  )}
                  {feedback.matchesAnswer !== undefined && (
                    <div className="flex items-center justify-between p-3 bg-white rounded-lg">
                      <span className="text-sm font-medium text-gray-700">Content Match:</span>
                      <span className={`font-bold text-sm ${feedback.matchesAnswer ? 'text-emerald-600' : 'text-red-600'}`}>
                        {feedback.matchesAnswer ? '✓ Matches' : '✗ Does Not Match'}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            )}

            <div className="bg-linear-to-r from-emerald-50 to-emerald-100 border-2 border-emerald-300 rounded-xl p-5 mb-6 shadow-sm">
              <p className="text-xl font-bold text-emerald-800">
                Points Earned: {feedback.points} / {clue.points}
              </p>
            </div>

            <Button
              onClick={() => setShowFeedbackModal(false)}
              fullWidth
              className="mt-2 font-bold text-lg py-3"
            >
              Continue
            </Button>
          </div>
        )}
      </Modal>
    </>
  );
}
