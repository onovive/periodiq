'use client';

import { useState, useRef } from 'react';
import Button from '@/components/ui/Button';

interface ClueInterfaceMobileProps {
  clue: {
    id: string;
    question: string;
    answer_type: string;
  };
  clueNumber: number;
  totalClues: number;
  previousSubmission?: {
    id: string;
    image_url: string | null;
    is_correct: boolean;
    ai_feedback: string | null;
  } | null;
  onSubmit: (imageFile: File) => Promise<{ success: boolean; isCorrect?: boolean; feedback?: string }>;
}

export default function ClueInterfaceMobile({
  clue,
  clueNumber,
  totalClues,
  previousSubmission,
  onSubmit,
}: ClueInterfaceMobileProps) {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const alreadyAnswered = !!previousSubmission;

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async () => {
    if (!imageFile || alreadyAnswered) return;

    setLoading(true);
    try {
      await onSubmit(imageFile);
      setImageFile(null);
      setImagePreview('');
    } catch (error) {
      console.error('Error submitting:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-3">
        <div className="flex items-center justify-between">
          <button className="p-2">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <div className="text-sm font-medium text-blue-600">
            Clue {clueNumber} of {totalClues}
          </div>
          <div className="w-6" /> {/* Spacer */}
        </div>
      </div>

      {/* Timer */}
      <div className="bg-red-50 px-4 py-2 text-center">
        <div className="text-red-600 font-medium text-sm">00:01:47</div>
      </div>

      {/* Content */}
      <div className="flex-1 px-4 py-6">
        {/* Clue */}
        <div className="mb-6">
          <div className="text-sm font-semibold text-gray-900 mb-2">Clue {clueNumber}</div>
          <div className="text-base text-gray-700">{clue.question}</div>
        </div>

        {/* Image Upload Area */}
        {alreadyAnswered ? (
          <div className="border-2 border-dashed border-gray-300 rounded-lg overflow-hidden">
            {previousSubmission?.image_url && (
              <img
                src={previousSubmission.image_url}
                alt="Submitted"
                className="w-full h-auto"
              />
            )}
          </div>
        ) : imagePreview ? (
          <div className="border-2 border-dashed border-gray-300 rounded-lg overflow-hidden">
            <img src={imagePreview} alt="Preview" className="w-full h-auto" />
          </div>
        ) : (
          <div className="border-2 border-dashed border-gray-300 rounded-lg bg-gray-50 flex items-center justify-center" style={{ minHeight: '200px' }}>
            <div className="text-center text-gray-400">
              <div className="text-sm italic">No photos uploaded.</div>
            </div>
          </div>
        )}

        {/* Upload Button */}
        {!alreadyAnswered && (
          <>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleImageSelect}
              className="hidden"
            />
            <Button
              onClick={() => fileInputRef.current?.click()}
              fullWidth
              variant="secondary"
              className="mt-4"
            >
              <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              Take a photo
            </Button>
          </>
        )}
      </div>

      {/* Navigation Footer */}
      <div className="border-t border-gray-200 px-4 py-4 bg-white">
        <div className="flex items-center justify-center gap-8">
          <button className="p-2" disabled={clueNumber === 1}>
            <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <button className="p-2" disabled={clueNumber === totalClues && !alreadyAnswered}>
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>

      {/* Submit Button (when image selected) */}
      {imageFile && !alreadyAnswered && (
        <div className="fixed bottom-20 left-0 right-0 px-4">
          <Button
            onClick={handleSubmit}
            fullWidth
            loading={loading}
            className="shadow-lg"
          >
            Submit Answer
          </Button>
        </div>
      )}
    </div>
  );
}
