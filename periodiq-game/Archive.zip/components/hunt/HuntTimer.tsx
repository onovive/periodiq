'use client';

import { useState, useEffect } from 'react';

interface HuntTimerProps {
  huntStartTime: string;
  durationMinutes: number;
  onTimeUp?: () => void;
}

export default function HuntTimer({ huntStartTime, durationMinutes, onTimeUp }: HuntTimerProps) {
  const [timeRemaining, setTimeRemaining] = useState(0);

  useEffect(() => {
    const calculateTimeRemaining = () => {
      const start = new Date(huntStartTime).getTime();
      const end = start + durationMinutes * 60 * 1000;
      const now = Date.now();
      const remaining = Math.max(0, end - now);

      if (remaining === 0 && onTimeUp) {
        onTimeUp();
      }

      return remaining;
    };

    setTimeRemaining(calculateTimeRemaining());

    const interval = setInterval(() => {
      setTimeRemaining(calculateTimeRemaining());
    }, 1000);

    return () => clearInterval(interval);
  }, [huntStartTime, durationMinutes, onTimeUp]);

  const minutes = Math.floor(timeRemaining / 60000);
  const seconds = Math.floor((timeRemaining % 60000) / 1000);

  const isLowTime = minutes < 5;
  const isVeryLowTime = minutes < 1;

  return (
    <div className={`
      bg-white rounded-lg shadow-md p-4 border-2
      ${isVeryLowTime ? 'border-red-500 animate-pulse' : isLowTime ? 'border-yellow-500' : 'border-emerald-500'}
    `}>
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <svg className={`w-6 h-6 mr-2 ${isVeryLowTime ? 'text-red-600' : isLowTime ? 'text-yellow-600' : 'text-emerald-600'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <span className="text-sm font-medium text-gray-600">Time Remaining</span>
        </div>
        <div className={`
          text-2xl font-bold
          ${isVeryLowTime ? 'text-red-600' : isLowTime ? 'text-yellow-600' : 'text-emerald-600'}
        `}>
          {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
        </div>
      </div>

      {isVeryLowTime && timeRemaining > 0 && (
        <p className="text-red-600 text-xs mt-2 font-semibold">
          Hurry! Time is running out!
        </p>
      )}

      {timeRemaining === 0 && (
        <p className="text-red-600 text-xs mt-2 font-semibold">
          Time&apos;s up!
        </p>
      )}
    </div>
  );
}
