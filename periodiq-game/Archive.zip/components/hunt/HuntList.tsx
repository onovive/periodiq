'use client';

import HuntCard from './HuntCard';
import { Database } from '@/lib/types/database';

type Hunt = Database['public']['Tables']['hunts']['Row'];

interface HuntListProps {
  hunts: (Hunt & { participant_count?: number; user_registered?: boolean })[];
}

export default function HuntList({ hunts }: HuntListProps) {
  const upcomingHunts = hunts.filter(h => h.status === 'upcoming' || h.status === 'active');
  const pastHunts = hunts.filter(h => h.status === 'completed');

  return (
    <div className="space-y-12">
      {/* Upcoming Hunts */}
      {upcomingHunts.length > 0 && (
        <section>
          <div className="flex items-center gap-4 mb-6">
            <h2 className="text-3xl font-bold text-gray-900">
              Upcoming Hunts
            </h2>
            <span className="px-4 py-1.5 bg-emerald-100 text-emerald-700 text-sm font-bold rounded-full shadow-sm">
              {upcomingHunts.length}
            </span>
          </div>
          <div className="space-y-5">
            {upcomingHunts.map((hunt) => (
              <HuntCard key={hunt.id} hunt={hunt} />
            ))}
          </div>
        </section>
      )}

      {/* Past Hunts */}
      {pastHunts.length > 0 && (
        <section>
          <div className="flex items-center gap-4 mb-6">
            <h2 className="text-3xl font-bold text-gray-900">
              Past Hunts
            </h2>
            <span className="px-4 py-1.5 bg-gray-100 text-gray-700 text-sm font-bold rounded-full shadow-sm">
              {pastHunts.length}
            </span>
          </div>
          <div className="space-y-5">
            {pastHunts.map((hunt) => (
              <HuntCard key={hunt.id} hunt={hunt} />
            ))}
          </div>
        </section>
      )}

      {upcomingHunts.length === 0 && pastHunts.length === 0 && (
        <div className="text-center py-24 bg-white rounded-2xl border-2 border-dashed border-gray-300 shadow-sm">
          <svg className="w-24 h-24 mx-auto text-gray-300 mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <h3 className="text-2xl font-bold text-gray-900 mb-3">No hunts available</h3>
          <p className="text-lg text-gray-600">Check back soon for new adventures!</p>
        </div>
      )}
    </div>
  );
}
