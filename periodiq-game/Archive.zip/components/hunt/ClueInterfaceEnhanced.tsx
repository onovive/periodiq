'use client';

import { useState } from 'react';
import Card from '@/components/ui/Card';
import Input from '@/components/ui/Input';
import Button from '@/components/ui/Button';
import Modal from '@/components/ui/Modal';
import ImageUpload from '@/components/hunt/ImageUpload';
import Spinner from '@/components/ui/Spinner';
import { Database } from '@/lib/types/database';

type Clue = Database['public']['Tables']['clues']['Row'] & {
  answer_type?: 'text' | 'image' | 'both';
  reference_image_url?: string | null;
};

type Submission = Database['public']['Tables']['submissions']['Row'] & {
  image_url?: string | null;
  ai_generated_detected?: boolean;
  web_match_detected?: boolean;
  object_match_detected?: boolean;
};

interface ClueInterfaceEnhancedProps {
  clue: Clue;
  clueNumber: number;
  totalClues: number;
  participantId: string;
  huntId: string;
  previousSubmission?: Submission | null;
  onSubmit: (answer: string, imageUrl?: string, storagePath?: string) => Promise<{
    success: boolean;
    feedback?: string;
    isCorrect?: boolean;
    pointsEarned?: number;
  }>;
}

export default function ClueInterfaceEnhanced({
  clue,
  clueNumber,
  totalClues,
  participantId,
  huntId,
  previousSubmission,
  onSubmit,
}: ClueInterfaceEnhancedProps) {
  const [textAnswer, setTextAnswer] = useState('');
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [storagePath, setStoragePath] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [validating, setValidating] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [feedback, setFeedback] = useState<{ message: string; isCorrect: boolean; points: number; details?: any } | null>(null);
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);

  const answerType = clue.answer_type || 'text';
  const alreadyAnswered = !!previousSubmission;

  const handleImageUpload = async (url: string, path: string) => {
    setImageUrl(url);
    setStoragePath(path);

    // If answer type is image only, automatically validate
    if (answerType === 'image') {
      await handleSubmit(null, url, path);
    }
  };

  const handleSubmit = async (e: React.FormEvent | null, imgUrl?: string, imgPath?: string) => {
    if (e) e.preventDefault();

    // Validation checks
    if (answerType === 'text' && !textAnswer.trim()) return;
    if (answerType === 'image' && !imgUrl && !imageUrl) return;
    if (answerType === 'both' && (!textAnswer.trim() || (!imgUrl && !imageUrl))) return;
    if (alreadyAnswered) return;

    setLoading(true);
    setValidating(true);

    try {
      const finalImageUrl = imgUrl || imageUrl;
      const finalStoragePath = imgPath || storagePath;

      // If image validation is needed, call validation API first
      if (finalImageUrl && clue.validation_type === 'ai') {
        const validationResponse = await fetch('/api/validate-image', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageUrl: finalImageUrl,
            expectedAnswer: clue.expected_answer,
            validationType: clue.validation_type,
          }),
        });

        const validationResult = await validationResponse.json();

        if (validationResult.aiGeneratedDetected) {
          setFeedback({
            message: validationResult.feedback,
            isCorrect: false,
            points: 0,
            details: validationResult.details,
          });
          setShowFeedbackModal(true);
          setImageUrl(null);
          setStoragePath(null);
          setLoading(false);
          setValidating(false);
          return;
        }

        if (validationResult.webMatchDetected) {
          setFeedback({
            message: validationResult.feedback,
            isCorrect: false,
            points: 0,
            details: validationResult.details,
          });
          setShowFeedbackModal(true);
          setImageUrl(null);
          setStoragePath(null);
          setLoading(false);
          setValidating(false);
          return;
        }

        if (!validationResult.objectMatchDetected) {
          setFeedback({
            message: validationResult.feedback,
            isCorrect: false,
            points: 0,
            details: validationResult.details,
          });
          setShowFeedbackModal(true);
          setImageUrl(null);
          setStoragePath(null);
          setLoading(false);
          setValidating(false);
          return;
        }
      }

      // Submit answer
      const result = await onSubmit(
        textAnswer.trim() || clue.expected_answer,
        finalImageUrl || undefined,
        finalStoragePath || undefined
      );

      if (result.success) {
        setFeedback({
          message: result.feedback || (result.isCorrect ? 'Correct!' : 'Incorrect answer'),
          isCorrect: result.isCorrect || false,
          points: result.pointsEarned || 0,
        });
        setShowFeedbackModal(true);
        setTextAnswer('');
        setImageUrl(null);
        setStoragePath(null);
      }
    } catch (error) {
      console.error('Error submitting answer:', error);
      setFeedback({
        message: 'An error occurred while submitting your answer',
        isCorrect: false,
        points: 0,
      });
      setShowFeedbackModal(true);
    } finally {
      setLoading(false);
      setValidating(false);
    }
  };

  return (
    <>
      <Card padding="lg" className="mb-6">
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold text-emerald-600">
              Clue {clueNumber} of {totalClues}
            </span>
            <span className="text-sm font-semibold text-gray-600">{clue.points} points</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-emerald-600 h-2 rounded-full transition-all"
              style={{ width: `${(clueNumber / totalClues) * 100}%` }}
            />
          </div>
        </div>

        <h2 className="text-2xl font-bold text-gray-900 mb-4">{clue.question}</h2>

        {clue.reference_image_url && (
          <div className="mb-4">
            <p className="text-sm text-gray-600 mb-2">Reference image:</p>
            <img
              src={clue.reference_image_url}
              alt="Reference"
              className="w-full max-w-md h-48 object-cover rounded-lg"
            />
          </div>
        )}

        {clue.hint && (
          <div className="mb-4">
            <button
              onClick={() => setShowHint(!showHint)}
              className="text-emerald-600 hover:text-emerald-700 font-medium flex items-center"
            >
              <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
                />
              </svg>
              {showHint ? 'Hide Hint' : 'Show Hint'}
            </button>
            {showHint && (
              <div className="mt-2 p-3 bg-yellow-50 border border-yellow-200 rounded-lg text-yellow-800">
                {clue.hint}
              </div>
            )}
          </div>
        )}

        {alreadyAnswered ? (
          <div
            className={`p-4 rounded-lg ${
              previousSubmission.is_correct
                ? 'bg-emerald-50 border border-emerald-200'
                : 'bg-red-50 border border-red-200'
            }`}
          >
            <div className="flex items-center mb-2">
              {previousSubmission.is_correct ? (
                <svg className="w-6 h-6 text-emerald-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              ) : (
                <svg className="w-6 h-6 text-red-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              )}
              <span className={`font-semibold ${previousSubmission.is_correct ? 'text-emerald-700' : 'text-red-700'}`}>
                {previousSubmission.is_correct ? 'Correct!' : 'Incorrect'}
              </span>
            </div>

            {previousSubmission.image_url ? (
              <div className="mb-2">
                <p className="text-sm text-gray-600 mb-1">Your uploaded image:</p>
                <img src={previousSubmission.image_url} alt="Submission" className="w-full max-w-md h-48 object-cover rounded-lg" />
                {previousSubmission.ai_generated_detected && (
                  <p className="text-red-600 text-sm mt-1">⚠️ AI-generated image detected</p>
                )}
                {previousSubmission.web_match_detected && (
                  <p className="text-red-600 text-sm mt-1">⚠️ Image found on web</p>
                )}
              </div>
            ) : (
              <p className="text-gray-700">Your answer: {previousSubmission.answer}</p>
            )}

            {previousSubmission.ai_feedback && (
              <p className="text-gray-600 mt-2 text-sm">{previousSubmission.ai_feedback}</p>
            )}
            <p className="text-gray-600 mt-2 font-semibold">Points earned: {previousSubmission.points_earned}</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            {(answerType === 'text' || answerType === 'both') && (
              <div className="mb-4">
                <Input
                  label={answerType === 'both' ? 'Text Answer (Optional)' : 'Your Answer'}
                  value={textAnswer}
                  onChange={(e) => setTextAnswer(e.target.value)}
                  placeholder="Enter your answer..."
                  disabled={loading || alreadyAnswered}
                />
              </div>
            )}

            {(answerType === 'image' || answerType === 'both') && (
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {answerType === 'both' ? 'Upload Photo (Required)' : 'Upload Photo'}
                </label>
                <ImageUpload
                  huntId={huntId}
                  clueId={clue.id}
                  onUploadComplete={handleImageUpload}
                  disabled={loading || alreadyAnswered}
                />
              </div>
            )}

            {validating && (
              <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-lg flex items-center">
                <Spinner size="sm" />
                <span className="ml-3 text-blue-700">Validating your image...</span>
              </div>
            )}

            {answerType !== 'image' && (
              <Button
                type="submit"
                fullWidth
                loading={loading}
                disabled={
                  !textAnswer.trim() ||
                  (answerType === 'both' && !imageUrl) ||
                  alreadyAnswered
                }
                className="mt-4"
              >
                Submit Answer
              </Button>
            )}
          </form>
        )}
      </Card>

      <Modal isOpen={showFeedbackModal} onClose={() => setShowFeedbackModal(false)} title="Answer Feedback">
        {feedback && (
          <div className="text-center">
            {feedback.isCorrect ? (
              <div className="mb-4">
                <svg className="w-16 h-16 text-emerald-500 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h3 className="text-2xl font-bold text-emerald-700 mt-4">Correct!</h3>
              </div>
            ) : (
              <div className="mb-4">
                <svg className="w-16 h-16 text-red-500 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h3 className="text-2xl font-bold text-red-700 mt-4">Incorrect</h3>
              </div>
            )}
            <p className="text-gray-700 mb-4">{feedback.message}</p>
            <p className="text-lg font-semibold text-gray-900">Points earned: {feedback.points}</p>
            <Button onClick={() => setShowFeedbackModal(false)} fullWidth className="mt-6">
              Continue
            </Button>
          </div>
        )}
      </Modal>
    </>
  );
}
